"""Locally-owned Chrome app-mode browser. No CDP TCP endpoint or Zalo private APIs.

All Playwright objects live in one worker thread. No authentication secrets,
message bodies or contact names are emitted to logs/ChatGPT.
"""
from __future__ import annotations
import json
import os
import queue
import re
import subprocess
import shutil
import sys
import threading
import time
import uuid
from pathlib import Path
from urllib.parse import urlparse

from session_rules import CHAT_URL, LOGIN_URL, Row, classify, merge_with_overlap, validate_page

CHROME_PATHS = [
    r"C:\Program Files\Google\Chrome\Application\chrome.exe",
    r"C:\Program Files (x86)\Google\Chrome\Application\chrome.exe",
]


def direct_chrome_args(profile, viewport=(500,25,1340,900)):
    x,y,w,h=viewport
    return [f'--user-data-dir={Path(profile)}',f'--window-position={x},{y}',
            f'--window-size={w},{h}','--no-first-run','--no-default-browser-check',
            '--app='+CHAT_URL]


def chrome_binary(paths=None) -> str | None:
    """Never launch browser executables from an incoming message or current working dir."""
    if paths is None:
        paths = CHROME_PATHS
    for path in paths:
        if Path(path).is_file():
            return str(Path(path))
    return None

# Read *visible* UI and only return session state booleans. No message text.
SESSION_PROBE_JS = r"""() => {
const view = e=>{if(!e)return false;const r=e.getBoundingClientRect(),s=getComputedStyle(e);
 return r.width>0&&r.height>0&&s.display!=='none'&&s.visibility!=='hidden'};
const controls=[...document.querySelectorAll('button,[role=button],input,[placeholder],[aria-label],h1,h2,h3')].filter(view);
const labels=controls.map(e=>`${e.getAttribute('aria-label')||''} ${e.getAttribute('placeholder')||''} ${e.tagName.match(/^H[123]$/)?e.textContent||'':''}`.toLowerCase());
// Zalo Web often renders its search placeholder in a sibling element rather
// than in the input. Its real Chromium accessibility tree exposes these IDs.
const has=id=>{const nodes=[...document.querySelectorAll('[id="'+id+'"]')];return nodes.length===1&&view(nodes[0]);};
return {
 qr:labels.some(x=>x.includes('đăng nhập qua mã qr')||x.includes('quét mã qr')),
 search:has('contact-search-input')||labels.some(x=>x.includes('tìm kiếm')||x.includes('search')),
 friends:has('sidebarNav')||labels.some(x=>x.includes('danh bạ')||x.includes('bạn bè')),
 chats:has('conversationListId')||labels.some(x=>x.includes('tin nhắn')||x.includes('trò chuyện')),
 login_form:labels.some(x=>x.includes('đăng nhập')||x.includes('login'))
};
}"""

# Structural diagnostic: numbers and booleans only. It NEVER extracts or logs
# Zalo contact names, chat text, tokens, QR or cookies.
FRIENDS_DIAGNOSTIC_JS = r"""() => {
const view=e=>{if(!e)return false;const r=e.getBoundingClientRect(),s=getComputedStyle(e);
 return r.width>0&&r.height>0&&s.visibility!=='hidden'&&s.display!=='none'};
const q=s=>[...document.querySelectorAll(s)].filter(view);
const labels=q('div,span,h1,h2,h3,[role="heading"]').filter(e=>
 e.children.length===0 && /^(?:Bạn bè\s*\(\d[\d.,]*\)|Danh sách bạn bè)$/i.test((e.textContent||'').replace(/\s+/g,' ').trim()));
const roots=q('[data-testid="friends-list"],[data-testid="friend-list"],[role="list"][aria-label="Danh sách bạn bè"],[role="grid"][aria-label="Danh sách bạn bè"]');
const scroll=q('div,[role="list"],[role="grid"]').filter(e=>e.clientHeight>=80&&e.scrollHeight>e.clientHeight+10);
return {schema:1,visible_headers:labels.length,verified_roots:roots.length,
 scroll_containers:scroll.length,visible_rows:q('[data-testid="friend-row"],[data-testid="contact-row"],[role="listitem"],[role="row"]').length,
 has_contact_rail:q('#sidebarNav').length===1,has_search:q('#contact-search-input').length===1};
}"""

# Strict friend list selectors. Fail closed when actual Zalo DOM differs.
FRIENDS_SNAPSHOT_JS = r"""() => {
const visible=e=>{const r=e.getBoundingClientRect(),s=getComputedStyle(e);
 return r.width>0&&r.height>0&&s.display!=='none'&&s.visibility!=='hidden'};
const roots=[...new Set(['[data-testid="friends-list"]','[data-testid="friend-list"]',
 '[role="list"][aria-label="Danh sách bạn bè"]','[role="grid"][aria-label="Danh sách bạn bè"]']
 .flatMap(s=>[...document.querySelectorAll(s)]))].filter(visible);
if(roots.length!==1)return {ok:false,reason:'FRIENDS_ROOT_NOT_VERIFIED'};
const h=[...document.querySelectorAll('[role="heading"],h1,h2,h3')].filter(visible)
 .map(x=>(x.innerText||'').replace(/\s+/g,' ').trim())
 .filter(x=>/^Danh sách bạn bè(?:\s*\([\d.,]+\))?$|^Bạn bè\s*\([\d.,]+\)$/.test(x));
if(h.length!==1)return {ok:false,reason:'FRIENDS_HEADING_NOT_VERIFIED'};
const m=h[0].match(/\(([\d.,]+)\)/);
if(!m)return {ok:false,reason:'FRIENDS_TOTAL_NOT_VERIFIED'};
const expected=Number(m[1].replace(/[.,]/g,''));
const root=roots[0],bounds=root.getBoundingClientRect();
const candidates=[...new Set([...root.querySelectorAll('[data-testid="friend-row"],[data-testid="contact-row"],[role="listitem"],[role="row"]')])].filter(visible)
.filter(x=>{const r=x.getBoundingClientRect();return r.bottom>bounds.top&&r.top<bounds.bottom})
.filter(x=>!([...root.querySelectorAll('[data-testid="friend-row"],[data-testid="contact-row"],[role="listitem"],[role="row"]')].some(y=>y!==x&&y.contains(x))))
.sort((a,b)=>a.getBoundingClientRect().top-b.getBoundingClientRect().top);
const rows=[];
for(const row of candidates){
 const names=[...row.querySelectorAll('[data-testid="friend-name"],[data-testid="contact-name"],.friend-name,.contact-name')].filter(visible);
 if(names.length!==1)return {ok:false,reason:'FRIEND_NAME_SELECTOR_UNVERIFIED'};
 const name=(names[0].innerText||'').replace(/\s+/g,' ').trim();
 if(!name||name.length>150)return {ok:false,reason:'FRIEND_NAME_INVALID'};
 const tags=[...row.querySelectorAll('[data-testid="friend-label"],.friend-label')].filter(visible)
 .map(x=>(x.innerText||'').replace(/\s+/g,' ').trim()).filter(Boolean).slice(0,12);
 rows.push({name,secondary:'',labels:tags});
}
return {ok:true,expected,rows,top:root.scrollTop,height:root.scrollHeight,viewport:root.clientHeight,
 atEnd:root.scrollTop+root.clientHeight>=root.scrollHeight-5};
}"""

FRIENDS_SCROLL_JS = r"""() => {
const roots=[...new Set(['[data-testid="friends-list"]','[data-testid="friend-list"]',
 '[role="list"][aria-label="Danh sách bạn bè"]','[role="grid"][aria-label="Danh sách bạn bè"]']
 .flatMap(s=>[...document.querySelectorAll(s)]))];
if(roots.length!==1)return false;
const el=roots[0], old=el.scrollTop;
el.scrollTop=Math.min(el.scrollHeight,old+Math.max(150,el.clientHeight*.65));
return el.scrollTop>old;
}"""
FRIENDS_RESET_JS = r"""() => {
const roots=[...new Set(['[data-testid="friends-list"]','[data-testid="friend-list"]',
 '[role="list"][aria-label="Danh sách bạn bè"]','[role="grid"][aria-label="Danh sách bạn bè"]']
 .flatMap(s=>[...document.querySelectorAll(s)]))];
if(roots.length!==1)return false;
roots[0].scrollTop=0;return roots[0].scrollTop===0;
}"""


def scan_verified(snapshot, scroll, reset, cancelled, on_progress, wait=lambda t: time.sleep(t), max_pages=1400):
    """Pure orchestration, no Zalo-specific network; imports nothing unless completed."""
    if not reset():
        raise RuntimeError('FRIENDS_START_UNVERIFIED')
    previous = []
    expected = None
    previous_top = None
    last_progress = None
    stagnant = 0
    for i in range(max_pages):
        if cancelled():
            raise RuntimeError('SCAN_CANCELLED')
        data = snapshot()
        if not data.get('ok'):
            raise RuntimeError(data.get('reason', 'FRIENDS_SNAPSHOT_UNVERIFIED'))
        count = data.get('expected')
        if expected is not None and count != expected:
            raise RuntimeError('FRIENDS_COUNT_CHANGED')
        if not isinstance(count,int):
            raise RuntimeError('FRIENDS_COUNT_UNVERIFIED')
        expected = count
        rows = [Row(name=z.get('name',''),secondary=z.get('secondary',''),labels=tuple(z.get('labels',[]))) for z in data.get('rows',[])]
        validate_page(rows,count,data['height'],data['viewport'],data['top'])
        if count>0 and not rows:
            raise RuntimeError('FRIENDS_ROWS_EMPTY')
        if count==0:
            if not data.get('atEnd'):
                raise RuntimeError('FRIENDS_END_UNVERIFIED')
            return {'friends': [], 'expectedCount': 0, 'seenCount': 0, 'ok': True, 'complete': True}
        previous=merge_with_overlap(previous,rows)
        if len(previous)>count:
            raise RuntimeError('FRIENDS_OVER_COUNT')
        on_progress(len(previous),count,i+1)
        if len(previous)==count:
            if not data['atEnd']:
                raise RuntimeError('FRIENDS_NOT_AT_END')
            return {'friends': [dict(name=x.name,secondary=x.secondary,labels=list(x.labels)) for x in previous],
                    'expectedCount':count,'seenCount':count,'ok':True,'complete':True,'method':'chrome-visible-dom'}
        if data['atEnd']:
            raise RuntimeError('FRIENDS_COUNT_MISMATCH')
        latest=(len(previous),data['top'])
        if latest==last_progress or data['top']==previous_top:
            stagnant+=1
        else:
            stagnant=0
        if stagnant>=5:
            raise RuntimeError('FRIENDS_SCAN_STALLED')
        previous_top=data['top'];last_progress=latest
        if not scroll():
            raise RuntimeError('FRIENDS_SCROLL_BLOCKED')
        wait(.2)
    raise RuntimeError('FRIENDS_PAGE_LIMIT')


def verified_search_locator(page):
    """Return the first unique, visible Zalo search field.

    A single DOM input can match id and placeholder simultaneously. Counting
    those selectors would wrongly treat one field as multiple people/searches.
    """
    for selector in ('#contact-search-input','input[placeholder="Tìm kiếm"]',
                     'input[aria-label="Tìm kiếm"]'):
        match=page.locator(selector)
        if match.count()==1 and match.is_visible():
            return match
    raise ValueError('CONTACT_SEARCH_UNVERIFIED')

class BrowserWorker:
    def __init__(self, local_data:Path, result_queue:queue.Queue, chrome_path=None, viewport=None):
        self.data=Path(local_data)
        self.result_queue=result_queue
        self.inbox=queue.Queue()
        self.thread=None
        self.stop_scan=threading.Event()
        self.chrome=chrome_path or chrome_binary()
        self.viewport=viewport or (500,25,1340,900)
        self.state='STOPPED'

    def start(self):
        if self.thread and self.thread.is_alive():return
        self.thread=threading.Thread(target=self._loop,name='ZaloChromeWorker',daemon=True)
        self.thread.start()
    def submit(self,action,**payload):
        action=action.lower()
        if action=='cancel_scan':
            self.stop_scan.set()
            return
        self.inbox.put((action,payload))
    def emit(self,event,**data):
        self.result_queue.put({'event':event,**data})
        # Record only closed-schema operational metadata, never names, QR, chat
        # contents, selectors that could embed sensitive data or arbitrary errors.
        allowed={'browser_started','browser_stopped','session','friend_probe',
                 'scan_result','error','browser_focused'}
        if event not in allowed:return
        import re
        safe={}
        for key in ('status','mode','profile','code'):
            value=data.get(key)
            if isinstance(value,str) and re.fullmatch(r'[A-Za-z0-9_]{1,80}',value):safe[key]=value
        for key in ('ready','count','visible_rows','ambiguous','ok'):
            value=data.get(key)
            if type(value) is bool or (type(value) is int and 0<=value<=20000):safe[key]=value
        diagnostic=data.get('diagnostic')
        if isinstance(diagnostic,dict):
            fields={'schema','visible_headers','verified_roots','scroll_containers',
                    'visible_rows','has_contact_rail','has_search'}
            safe['diagnostic']={k:v for k,v in diagnostic.items() if k in fields and
                (type(v) is bool or (type(v) is int and 0<=v<=20000))}
        try:
            import json
            from datetime import datetime,timezone
            report={'schema':'zalo.standalone.runtime.v1','event':event,
                    'at':datetime.now(timezone.utc).isoformat(),**safe}
            out=self.data/'runtime-health.json'
            out.parent.mkdir(parents=True,exist_ok=True)
            temporary=out.with_suffix('.tmp')
            temporary.write_text(json.dumps(report,ensure_ascii=False,sort_keys=True),'utf-8')
            temporary.replace(out)
        except OSError:pass

    def _loop(self):
        if not self.chrome:
            self.emit('error',code='CHROME_NOT_INSTALLED');return
        try:
            from playwright.sync_api import sync_playwright
        except ImportError:
            self.emit('error',code='PLAYWRIGHT_NOT_INSTALLED');return
        self.data.mkdir(parents=True,exist_ok=True)
        profile=self.data/'ChromeProfile'
        profile.mkdir(exist_ok=True)
        x,y,w,h=self.viewport
        args=[f'--window-position={x},{y}',f'--window-size={w},{h}',
              '--no-first-run','--no-default-browser-check','--app='+CHAT_URL]
        context=None
        try:
            with sync_playwright() as p:
                context=p.chromium.launch_persistent_context(str(profile),executable_path=self.chrome,
                    headless=False,accept_downloads=False,no_viewport=True,args=args,
                    timeout=25000,ignore_https_errors=False)
                self.state='ACTIVE'
                pages=[v for v in context.pages if not v.is_closed()]
                page=pages[0] if pages else context.new_page()
                if classify(page.url) not in ('CHAT_OR_LOGIN','LOGIN'):
                    try:page.goto(CHAT_URL,wait_until='domcontentloaded',timeout=30000)
                    except Exception:
                        # Keep Chrome open during a temporary network/login redirect failure.
                        # User can retry from the app; never dump redirect URL or QR data.
                        self.emit('error',code='ZALO_NAVIGATION_PENDING')
                self.emit('browser_started',profile='own_profile',mode='CHROME_APP')
                self._process(context,page)
        except Exception as exc:
            # Still allow ordinary Zalo Web login/chat if this Chrome installation
            # does not permit Playwright. The fallback has NO DOM automation.
            if context is None:
                try:
                    subprocess.Popen([self.chrome,*direct_chrome_args(profile,self.viewport)],
                         stdin=subprocess.DEVNULL,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,
                         close_fds=True)
                    self.emit('browser_started',profile='own_profile',mode='CHROME_DIRECT_FALLBACK')
                    self.emit('error',code='LOCAL_AUTOMATION_UNAVAILABLE')
                except Exception as launch_error:
                    self.emit('error',code='CHROME_CANNOT_START',detail=type(launch_error).__name__)
            else:
                # Only exception class, never URLs/auth redirect params or contents.
                self.emit('error',code='CHROME_SESSION_ERROR',detail=type(exc).__name__)
        finally:
            if context:
                try:context.close()
                except Exception:pass
            self.state='STOPPED'
            self.emit('browser_stopped')

    def _process(self,context,page):
        while True:
            try:action,data=self.inbox.get(timeout=.4)
            except queue.Empty:
                if page.is_closed():
                    self.emit('error',code='ZALO_WINDOW_CLOSED')
                    return
                continue
            if action=='shutdown':return
            if action=='open':
                try:
                    if page.is_closed():page=context.new_page()
                    if classify(page.url) not in ('CHAT_OR_LOGIN','LOGIN'):
                        page.goto(CHAT_URL,wait_until='domcontentloaded',timeout=30000)
                    page.bring_to_front()
                    self.emit('browser_focused')
                except Exception as e:self.emit('error',code='CHROME_OPEN_FAILED',detail=type(e).__name__)
            elif action=='session':
                try:
                    hints=page.evaluate(SESSION_PROBE_JS)
                    kind=classify(page.url)
                    if kind=='MARKETING':state='MARKETING'
                    elif kind=='UNTRUSTED' or kind=='OTHER':state='UNVERIFIED'
                    elif kind=='LOGIN' or hints.get('qr'):state='QR_REQUIRED'
                    elif hints.get('search') and (hints.get('friends') or hints.get('chats')):state='CHAT_READY'
                    else:state='UNVERIFIED'
                    self.emit('session',status=state)
                except Exception as e:self.emit('error',code='SESSION_PROBE_FAILED',detail=type(e).__name__)
            elif action=='probe':
                try:
                    if classify(page.url)!='CHAT_OR_LOGIN':raise ValueError('CHAT_VIEW_REQUIRED')
                    diagnostic=page.evaluate(FRIENDS_DIAGNOSTIC_JS)
                    if not isinstance(diagnostic,dict):diagnostic={'schema':1}
                    d=page.evaluate(FRIENDS_SNAPSHOT_JS)
                    if d.get('ok'):
                        self.emit('friend_probe',ready=True,count=d['expected'],visible_rows=len(d['rows']),diagnostic=diagnostic)
                    else:self.emit('friend_probe',ready=False,code=d.get('reason','FRIENDS_UNVERIFIED'),diagnostic=diagnostic)
                except Exception as e:self.emit('friend_probe',ready=False,code=str(e)[:55])
            elif action=='scan':
                if classify(page.url)!='CHAT_OR_LOGIN':
                    self.emit('scan_result',ok=False,code='CHAT_VIEW_REQUIRED');continue
                self.stop_scan.clear()
                try:
                    result=scan_verified(lambda:page.evaluate(FRIENDS_SNAPSHOT_JS),
                        lambda:page.evaluate(FRIENDS_SCROLL_JS),lambda:page.evaluate(FRIENDS_RESET_JS),
                        self.stop_scan.is_set,lambda seen,total,n:self.emit('scan_progress',seen=seen,expected=total,page=n))
                    # Never put names into any UI/log; only local data layer receives full snapshot.
                    from crm_runtime import import_full_scan
                    receipt=import_full_scan(result)
                    self.emit('scan_result',ok=True,count=receipt['count'],ambiguous=receipt['ambiguous'])
                except Exception as e:self.emit('scan_result',ok=False,code=str(e)[:65])
            elif action=='search':
                name=str(data.get('name','')).strip()
                if not 2<=len(name)<=140:
                    self.emit('error',code='SEARCH_TERM_INVALID');continue
                try:
                    if classify(page.url)!='CHAT_OR_LOGIN':raise ValueError('CHAT_VIEW_REQUIRED')
                    input_field=verified_search_locator(page)
                    input_field.fill(name)
                    self.emit('search_ready',status='CHOOSE_CORRECT_CONTACT_MANUALLY')
                except Exception as e:self.emit('error',code=str(e)[:65])
            else:self.emit('error',code='UNKNOWN_ACTION')
