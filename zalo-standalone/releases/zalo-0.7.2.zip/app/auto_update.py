"""Background release checking through the fixed Windows launcher only.

This module cannot provide a feed URL, unsigned archive or executable program
for the launcher to execute. All publisher trust decisions live in the compiled
Windows installer/updater. No Chrome sessions, contact data or Zalo cookies used.
"""
from __future__ import annotations
import ctypes
import json
import os
import re
from pathlib import Path
import subprocess


def installed_launcher(base=None):
    if base is None:
        base = Path(os.environ.get('LOCALAPPDATA') or Path.home()/'AppData'/'Local')
    return Path(base)/'Programs'/'ThayLinhZaloStandalone'/'ZaloStandaloneManager.exe'


def update_receipt_path(data=None):
    if data is None:
        data=Path(os.environ.get('ZALO_STANDALONE_DATA') or
                  Path(os.environ.get('APPDATA') or Path.home()/'AppData'/'Roaming')/'ThayLinhZaloStandalone')
    return Path(data)/'update-status.json'


def idle_seconds():
    if os.name!='nt':return 3600
    class LASTINPUTINFO(ctypes.Structure):
        _fields_=[('cbSize',ctypes.c_uint),('dwTime',ctypes.c_uint)]
    info=LASTINPUTINFO();info.cbSize=ctypes.sizeof(info)
    try:
        if not ctypes.windll.user32.GetLastInputInfo(ctypes.byref(info)):
            return 0
        tick=ctypes.windll.kernel32.GetTickCount64
        tick.restype=ctypes.c_ulonglong
        return ((tick()-info.dwTime)&0xFFFFFFFF)/1000
    except Exception:return 0



# Render only finite, known launcher states in the user interface. Network or
# parsing errors cannot inject uncontrolled strings into the app status label.
_UPDATE_STATES=frozenset({'UP_TO_DATE','CHECK_UNAVAILABLE','STAGED_FOR_RESTART'})
_SEMVER=re.compile(r'^(?:0|[1-9]\d{0,5})\.(?:0|[1-9]\d{0,5})\.(?:0|[1-9]\d{0,5})$')

def read_update_status(path=None):
    """Sanitized status only; deliberately excludes remote URL, keys and data."""
    p=Path(path) if path else update_receipt_path()
    try:
        if p.stat().st_size > 8192:
            return {'state':'INVALID_RECEIPT'}
        data=json.loads(p.read_text('utf-8'))
        if not isinstance(data,dict):raise ValueError('bad receipt')
        state=data.get('state')
        if state not in _UPDATE_STATES:
            return {'state':'INVALID_RECEIPT'}
        clean={'state':state}
        for field in ('current','next'):
            value=data.get(field)
            if isinstance(value,str) and _SEMVER.fullmatch(value):clean[field]=value
        return clean
    except FileNotFoundError:
        return {'state':'NO_RECEIPT'}
    except (OSError,ValueError,UnicodeError,TypeError):
        return {'state':'INVALID_RECEIPT'}


def newer_version_ready(path=None):
    """Only a well-formed staged version from the installed updater is eligible."""
    status=read_update_status(path)
    return status.get('next') if status['state']=='STAGED_FOR_RESTART' else None


def check_update_background(event_queue):
    launcher=installed_launcher()
    completed=False
    try:
        if launcher.is_file():
            # Hardcoded, approved updater command only. No arbitrary shell/args.
            result=subprocess.run([str(launcher),'--update'],stdin=subprocess.DEVNULL,
                stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,cwd=str(launcher.parent),
                timeout=105,check=False)
            completed=result.returncode==0
    except (OSError,subprocess.TimeoutExpired):pass
    finally:
        event_queue.put({'event':'update_check_done','launcher_ok':completed})
