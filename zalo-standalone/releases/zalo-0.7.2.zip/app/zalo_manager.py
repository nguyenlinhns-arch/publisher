"""Zalo Personal Manager 0.7.1 — independent Chrome-managed application.

Only genuine Google Chrome renders chat.zalo.me. The local Tk UI owns CRM and
is never granted the Zalo page's credentials. No Hub/MXH/Flow2 integration.
"""
from __future__ import annotations
import json
import os
import queue
import threading
import subprocess
import time
import tkinter as tk
from pathlib import Path
from tkinter import ttk, messagebox, simpledialog

import crm_runtime as crm
from core import make_draft, SEGMENTS
from browser_controller import BrowserWorker, chrome_binary
from auto_update import installed_launcher, idle_seconds, check_update_background, newer_version_ready, read_update_status

VERSION='0.7.2'
INK='#122033';BG='#eef4fa';NAVY='#123f7d';WHITE='#ffffff';MUTED='#66788d';GREEN='#087b64'


def contact_permission(row:dict)->bool:
    return row.get('consent')=='yes' and not row.get('do_not_contact') and not row.get('needs_review')


class Manager(tk.Tk):
    def __init__(self, run_browser=True):
        super().__init__()
        self.title(f'Zalo Personal Manager — Chrome độc lập v{VERSION}')
        self.geometry('610x900+12+42')
        self.minsize(540,680)
        self.configure(bg=BG)
        self.events=queue.Queue()
        self.worker=None
        self.contacts={}
        self.selected_id=None
        self.last_draft=''
        self.scan_in_progress=False
        self.update_check_busy=False
        self.last_update_checked_at=0.0
        self.new_version_ready=None
        self.restarting_for_update=False
        self.segment=tk.StringVar(value='Tất cả')
        self.search_var=tk.StringVar()
        self.state_label=tk.StringVar(value='Chưa mở Chrome riêng')
        self.scan_label=tk.StringVar(value='Danh bạ: chưa quét. Mở mục Danh sách bạn bè trên Zalo trước.')
        self.people_label=tk.StringVar(value='0 liên hệ CRM')
        self.selected_name=tk.StringVar(value='Chọn một liên hệ từ danh sách')
        self.person_segment=tk.StringVar(value='Chưa phân loại')
        self.person_consent=tk.StringVar(value='unknown')
        self.person_blocked=tk.BooleanVar(value=False)
        self.person_region=tk.StringVar()
        self._init_style()
        self._build()
        try:
            crm.initialize_db()
            self.refresh_contacts()
        except Exception as exc:
            self.after(50,lambda e=str(exc):messagebox.showerror('Cơ sở dữ liệu',e))
        self.search_var.trace_add('write',lambda *a:self.after(150,self.refresh_contacts))
        self.protocol('WM_DELETE_WINDOW',self._close)
        if run_browser:
            root=Path(os.environ.get('LOCALAPPDATA',str(Path.home()/'.local'/'share')))/'ThayLinhZaloStandalone'
            w=max(850,self.winfo_screenwidth()-650)
            h=max(600,self.winfo_screenheight()-110)
            self.worker=BrowserWorker(root,self.events,viewport=(630,45,w,h))
            self.worker.start()
        self.after(250,self._poll)
        self.after(100,self._publish_startup_ready)
        if run_browser:
            # Unattended check starts after the UI is ready and the owner is idle.
            self.after(90_000,self._auto_update_tick)


    def _publish_startup_ready(self):
        try:
            file=crm.DATA_ROOT/'startup-health.json'
            file.parent.mkdir(parents=True,exist_ok=True)
            temporary=file.with_suffix('.tmp')
            temporary.write_text(json.dumps({'state':'READY','version':VERSION,'pid':os.getpid()},
                  ensure_ascii=False),encoding='utf-8')
            temporary.replace(file)
        except OSError:pass

    def _init_style(self):
        sty=ttk.Style(self)
        try:sty.theme_use('clam')
        except tk.TclError:pass
        sty.configure('TFrame',background=BG)
        sty.configure('TLabel',background=BG,foreground=INK,font=('Segoe UI',10))
        sty.configure('Header.TLabel',font=('Segoe UI',17,'bold'),foreground=NAVY)
        sty.configure('Sub.TLabel',foreground=MUTED,font=('Segoe UI',9))
        sty.configure('TLabelframe',background=WHITE,bordercolor='#d5dfeb')
        sty.configure('TLabelframe.Label',font=('Segoe UI',10,'bold'),foreground=NAVY,background=WHITE)
        sty.configure('Treeview',background=WHITE,foreground=INK,fieldbackground=WHITE,rowheight=29,font=('Segoe UI',9))
        sty.configure('Treeview.Heading',background='#dbe7f5',font=('Segoe UI',9,'bold'))
        sty.configure('TButton',padding=(10,7),font=('Segoe UI',9))
        sty.configure('Primary.TButton',background=NAVY,foreground=WHITE)
        sty.map('Primary.TButton',background=[('active','#2560a8')])
        sty.configure('TCombobox',padding=3)

    def _btn(self,parent,text,command,primary=False):
        return ttk.Button(parent,text=text,command=command,style='Primary.TButton' if primary else 'TButton')

    def _build(self):
        head=ttk.Frame(self,padding=(18,15,18,9));head.pack(fill='x')
        ttk.Label(head,text='ZALO PERSONAL MANAGER',style='Header.TLabel').pack(anchor='w')
        ttk.Label(head,text='Chrome riêng • Danh bạ CRM • Không liên quan luồng 2',style='Sub.TLabel').pack(anchor='w')

        panel=ttk.LabelFrame(self,text='Phiên Zalo Web chính thức',padding=(12,8))
        panel.pack(fill='x',padx=12,pady=(0,9))
        ttk.Label(panel,textvariable=self.state_label,wraplength=540).pack(anchor='w',pady=(2,8))
        line=ttk.Frame(panel);line.pack(fill='x')
        self._btn(line,'Mở Zalo Web',lambda:self.dispatch('open'),True).pack(side='left',padx=(0,6))
        self._btn(line,'Kiểm tra phiên',lambda:self.dispatch('session')).pack(side='left')
        self._btn(line,'Kiểm tra cập nhật',self.check_update_now).pack(side='left',padx=(6,0))
        ttk.Label(panel,text='Lần đầu: quét QR và xác nhận trên điện thoại. Những lần sau Chrome sẽ giữ phiên riêng.',style='Sub.TLabel',wraplength=540).pack(anchor='w',pady=(8,2))

        scan=ttk.LabelFrame(self,text='Quét danh bạ (chỉ đọc)',padding=(12,8));scan.pack(fill='x',padx=12,pady=(0,9))
        sbuttons=ttk.Frame(scan);sbuttons.pack(fill='x')
        self._btn(sbuttons,'Kiểm tra danh bạ',lambda:self.dispatch('probe')).pack(side='left',padx=(0,5))
        self._btn(sbuttons,'Quét đầy đủ',lambda:self.dispatch('scan')).pack(side='left',padx=(0,5))
        self._btn(sbuttons,'Dừng',lambda:self.dispatch('cancel_scan')).pack(side='left')
        ttk.Label(scan,textvariable=self.scan_label,style='Sub.TLabel',wraplength=540).pack(anchor='w',pady=(8,0))

        contacts=ttk.LabelFrame(self,text='Quản lý liên hệ',padding=(10,7));contacts.pack(fill='both',expand=True,padx=12,pady=(0,8))
        top=ttk.Frame(contacts);top.pack(fill='x')
        ttk.Label(top,textvariable=self.people_label,style='Sub.TLabel').pack(side='left')
        self._btn(top,'+ Thêm',self.add_contact).pack(side='right')
        search=ttk.Frame(contacts);search.pack(fill='x',pady=(6,7))
        ttk.Entry(search,textvariable=self.search_var,width=26).pack(side='left',fill='x',expand=True,padx=(0,7))
        ttk.Combobox(search,textvariable=self.segment,values=['Tất cả',*SEGMENTS],state='readonly',width=20).pack(side='right')
        self.segment.trace_add('write',lambda *a:self.refresh_contacts())
        treewrap=ttk.Frame(contacts);treewrap.pack(fill='both',expand=True)
        self.tree=ttk.Treeview(treewrap,columns=('name','segment'),show='headings',selectmode='browse',height=7)
        self.tree.heading('name',text='Tên liên hệ');self.tree.heading('segment',text='Phân loại')
        self.tree.column('name',width=200,anchor='w');self.tree.column('segment',width=175,anchor='w')
        scr=ttk.Scrollbar(treewrap,orient='vertical',command=self.tree.yview)
        self.tree.configure(yscrollcommand=scr.set)
        self.tree.pack(side='left',fill='both',expand=True);scr.pack(side='right',fill='y')
        self.tree.bind('<<TreeviewSelect>>',self.select_contact)

        edit=ttk.LabelFrame(self,text='Hồ sơ & bản nháp',padding=(12,8));edit.pack(fill='both',padx=12,pady=(0,9))
        ttk.Label(edit,textvariable=self.selected_name,font=('Segoe UI',10,'bold'),wraplength=510).pack(anchor='w')
        fields=ttk.Frame(edit);fields.pack(fill='x',pady=(7,4))
        ttk.Label(fields,text='Nhóm:').grid(row=0,column=0,sticky='w')
        ttk.Combobox(fields,textvariable=self.person_segment,values=SEGMENTS,state='readonly',width=27).grid(row=0,column=1,sticky='w',padx=7)
        ttk.Label(fields,text='Đồng ý:').grid(row=0,column=2,sticky='w')
        ttk.Combobox(fields,textvariable=self.person_consent,values=['unknown','yes','no'],state='readonly',width=10).grid(row=0,column=3,sticky='w',padx=7)
        ttk.Checkbutton(edit,text='Không liên hệ',variable=self.person_blocked).pack(anchor='w')
        ttk.Entry(edit,textvariable=self.person_region).pack(fill='x',pady=3)
        ttk.Label(edit,text='Ghi chú / nơi ở chỉ khi đã xác minh:',style='Sub.TLabel').pack(anchor='w')
        self.notes=tk.Text(edit,height=2,wrap='word',relief='solid',bd=1,font=('Segoe UI',9))
        self.notes.pack(fill='x',pady=(3,6))
        buttons=ttk.Frame(edit);buttons.pack(fill='x')
        self._btn(buttons,'Lưu hồ sơ',self.save_profile,True).pack(side='left',padx=(0,6))
        self._btn(buttons,'Tìm trên Zalo',self.find_on_zalo).pack(side='left',padx=(0,6))
        self._btn(buttons,'Tạo bản nháp',self.generate_draft).pack(side='left')
        self.draft=tk.Text(edit,height=3,wrap='word',relief='solid',bd=1,font=('Segoe UI',9))
        self.draft.pack(fill='x',pady=(8,4))
        draft_buttons=ttk.Frame(edit);draft_buttons.pack(fill='x')
        self._btn(draft_buttons,'Lưu bản nháp',self.save_draft,True).pack(side='left',padx=(0,8))
        self._btn(draft_buttons,'Sao chép bản nháp',self.copy_draft).pack(side='left')
        footer=ttk.Frame(self,padding=(14,1,14,11));footer.pack(fill='x')
        ttk.Label(footer,text='Không tự gửi tin • Không đọc token/cookie • Không quét bằng GPT',style='Sub.TLabel').pack(side='left')
        ttk.Label(footer,text='v'+VERSION,style='Sub.TLabel').pack(side='right')

    def dispatch(self,command,**kwargs):
        if command=='cancel_scan' and self.worker:self.worker.submit(command);self.scan_label.set('Đã yêu cầu dừng');return
        if command=='scan':self.scan_in_progress=True
        if not self.worker:
            self.state_label.set('Chrome worker chưa sẵn sàng');return
        if not self.worker.thread or not self.worker.thread.is_alive():
            self.worker.start()
        self.worker.submit(command,**kwargs)

    def _poll(self):
        try:
            while True:
                x=self.events.get_nowait();evt=x['event']
                if evt=='browser_started':self.state_label.set('Chrome riêng đã mở. Đăng nhập Zalo qua QR nếu được yêu cầu.')
                elif evt=='session':
                    labels={'CHAT_READY':'Đã nhận diện giao diện Zalo Web', 'QR_REQUIRED':'Chờ quét/xác nhận QR trên điện thoại',
                       'UNVERIFIED':'Chưa xác minh trạng thái đăng nhập', 'MARKETING':'Đang ở trang giới thiệu, không phải chat'}
                    self.state_label.set(labels.get(x.get('status'),x.get('status','Chưa xác minh')))
                elif evt=='browser_focused':self.state_label.set('Đã mở Chrome riêng của Zalo')
                elif evt=='friend_probe':
                    self.scan_label.set(f"Danh bạ: {x['count']} người, {x['visible_rows']} hàng đang thấy" if x.get('ready') else f"Chưa hỗ trợ màn hình này: {x.get('code','không rõ')}")
                elif evt=='scan_progress':self.scan_label.set(f"Đang quét: {x['seen']}/{x['expected']} — trang {x['page']}")
                elif evt=='scan_result':
                    self.scan_in_progress=False
                    self.scan_label.set(f"Quét xong {x['count']} liên hệ; cần xét {x['ambiguous']} tên trùng" if x.get('ok') else f"Chưa nhập danh bạ: {x.get('code','không rõ')}")
                    if x.get('ok'):self.refresh_contacts()
                elif evt=='search_ready':self.state_label.set('Đã tìm tên. Hãy chọn và xác minh đúng người trong Chrome.')
                elif evt=='error':
                    self.scan_in_progress=False
                    self.state_label.set(f"Lỗi: {x.get('code','không xác định')}")
                elif evt=='browser_stopped':self.state_label.set('Chrome riêng đã dừng')
                elif evt=='update_check_done':
                    self.update_check_busy=False
                    latest=newer_version_ready()
                    if latest and latest!=VERSION:
                        self.new_version_ready=latest
                        self.state_label.set(f'Đã xác minh bản {latest}. Tự chuyển phiên bản khi PC rảnh.')
                        self.after(30_000,self._auto_restart_if_safe)
                    else:
                        status=read_update_status()
                        state=status['state']
                        if state=='UP_TO_DATE':
                            self.state_label.set('Phiên bản hiện tại đã mới nhất theo nguồn cập nhật đã xác thực.')
                        elif state=='CHECK_UNAVAILABLE':
                            self.state_label.set('Chưa kiểm tra được nguồn phát hành đáng tin cậy. Giữ nguyên bản đang chạy.')
                        elif state=='NO_RECEIPT':
                            self.state_label.set('Chưa có biên nhận từ updater. Chưa thực hiện nâng cấp.')
                        else:
                            self.state_label.set('Chưa có bản cập nhật hợp lệ để kích hoạt.')

        except queue.Empty:pass
        self.after(300,self._poll)


    def check_update_now(self):
        """Only asks the installed signed launcher to check its pinned feed."""
        if self.update_check_busy or self.restarting_for_update or self.scan_in_progress:
            self.state_label.set('Đang có tác vụ; kiểm tra cập nhật sau khi hoàn tất.')
            return
        if self.draft.edit_modified():
            self.state_label.set('Đang sửa bản nháp; lưu trước khi kiểm tra cập nhật.')
            return
        if not installed_launcher().is_file():
            self.state_label.set('Chưa tìm thấy launcher cài đặt, không chạy cập nhật tùy ý.')
            return
        self.update_check_busy=True
        self.last_update_checked_at=time.monotonic()
        self.state_label.set('Đang kiểm tra nguồn phát hành có chữ ký...')
        threading.Thread(target=check_update_background,args=(self.events,),
            daemon=True,name='ZaloSignedUpdateCheckManual').start()

    def _auto_update_tick(self):
        """Only the fixed installed launcher can fetch/verify updates; no arbitrary shell."""
        if self.restarting_for_update:return
        if self.new_version_ready:
            self._auto_restart_if_safe()
            self.after(45_000,self._auto_update_tick)
            return
        if (not self.update_check_busy and not self.scan_in_progress and
                time.monotonic()-self.last_update_checked_at >= 6*60*60 and
                idle_seconds() >= 180 and installed_launcher().is_file()):
            self.update_check_busy=True
            self.last_update_checked_at=time.monotonic()
            threading.Thread(target=check_update_background,
                args=(self.events,),daemon=True,name='ZaloSignedUpdateCheck').start()
        self.after(60_000,self._auto_update_tick)

    def _auto_restart_if_safe(self):
        if not self.new_version_ready or self.restarting_for_update:return
        if self.scan_in_progress or idle_seconds() < 300:return
        if self.draft.edit_modified():return
        self.restarting_for_update=True
        self.state_label.set('Cập nhật đã xác minh. Đang chuyển sang bản mới...')
        if self.worker:self.worker.submit('shutdown')
        self.after(500,lambda:self._finish_update_restart(0))

    def _finish_update_restart(self,retries):
        if self.worker and self.worker.thread and self.worker.thread.is_alive():
            if retries<20:
                self.after(500,lambda:self._finish_update_restart(retries+1))
            else:
                self.restarting_for_update=False
                self.state_label.set('Đã chuẩn bị bản cập nhật; ứng dụng sẽ dùng sau lần mở tiếp theo.')
            return
        launcher=installed_launcher()
        try:
            subprocess.Popen([str(launcher),'--launch'],cwd=str(launcher.parent),
                stdin=subprocess.DEVNULL,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,
                close_fds=True)
        except OSError:
            self.restarting_for_update=False
            self.state_label.set('Đã lưu bản cập nhật. Mở lại ứng dụng để kích hoạt.')
            return
        self.destroy()

    def refresh_contacts(self):
        try:
            rows,total=crm.load_contacts(self.search_var.get(),self.segment.get(),500)
        except Exception:
            return
        current=self.selected_id
        self.tree.delete(*self.tree.get_children())
        self.contacts={r['id']:r for r in rows}
        for x in rows:
            self.tree.insert('', 'end',iid=x['id'],values=(x['name'],x['segment']))
        self.people_label.set(f'{total} liên hệ trong CRM'+(' (hiện tối đa 500)' if total>500 else ''))
        if current in self.contacts:self.tree.selection_set(current)

    def select_contact(self,event=None):
        items=self.tree.selection()
        if not items:return
        k=items[0];row=self.contacts.get(k)
        if not row:return
        self.selected_id=k
        self.selected_name.set(row['name']+(' — cần xác minh' if row.get('needs_review') else ''))
        self.person_segment.set(row.get('segment') or SEGMENTS[0]);self.person_consent.set(row.get('consent') or 'unknown')
        self.person_blocked.set(bool(row.get('do_not_contact')))
        self.person_region.set(row.get('region') or '')
        self.notes.delete('1.0','end');self.notes.insert('1.0',row.get('notes') or '')
        self.draft.delete('1.0','end')
        try:
            saved=crm.load_saved_draft(k)
            if saved:self.draft.insert('1.0',saved['body'])
            self.draft.edit_modified(False)
        except Exception:
            self.state_label.set('Bản nháp chưa đọc được; không ảnh hưởng hồ sơ liên hệ')

    def add_contact(self):
        name=simpledialog.askstring('Liên hệ CRM','Tên người liên hệ (chỉ lưu trong app):',parent=self)
        if not name:return
        try:crm.add_manual_contact(name);self.refresh_contacts()
        except Exception as e:messagebox.showwarning('Chưa thêm',str(e),parent=self)

    def save_profile(self):
        if not self.selected_id:return
        try:
            crm.update_contact(self.selected_id,self.person_segment.get(),self.person_consent.get(),
                self.person_blocked.get(),self.notes.get('1.0','end-1c'),self.person_region.get())
            self.refresh_contacts()
            messagebox.showinfo('Đã lưu','Đã lưu vào cơ sở dữ liệu CRM riêng.',parent=self)
        except Exception as e:messagebox.showerror('Không lưu được',str(e),parent=self)

    def generate_draft(self):
        if not self.selected_id:return
        row=self.contacts.get(self.selected_id)
        try:
            with crm.connect() as conn:
                full=conn.execute('SELECT * FROM contacts WHERE id=?',(self.selected_id,)).fetchone()
            if full is None:return
            r=make_draft(full)
            if not r.get('ok'):
                messagebox.showinfo('Chưa có bản nháp',r.get('reason','Cần kiểm tra hồ sơ'),parent=self);return
            text=r.get('message') or r.get('text') or ''
            if not text:return
            current=self.draft.get('1.0','end-1c')
            if current.strip() and current != text:
                if not messagebox.askyesno('Thay bản nháp','Thay nội dung đang hiển thị bằng bản nháp gợi ý? Nội dung cũ đã lưu sẽ vẫn được giữ trong dữ liệu cho đến khi bạn bấm Lưu bản nháp.',parent=self):return
            self.draft.delete('1.0','end');self.draft.insert('1.0',text)
        except Exception as e:messagebox.showwarning('Bản nháp',str(e),parent=self)

    def save_draft(self):
        if not self.selected_id:return
        body=self.draft.get('1.0','end-1c')
        try:
            receipt=crm.store_draft(self.selected_id,body)
            self.draft.edit_modified(False)
            self.state_label.set(f"Đã lưu bản nháp cục bộ (phiên bản {receipt['revision']}). Chưa gửi Zalo.")
        except Exception as e:
            messagebox.showwarning('Chưa lưu bản nháp',str(e),parent=self)

    def copy_draft(self):
        text=self.draft.get('1.0','end-1c').strip()
        if text:
            self.clipboard_clear();self.clipboard_append(text)
            self.state_label.set('Đã sao chép bản nháp. Chưa gửi Zalo.')

    def find_on_zalo(self):
        if self.selected_id in self.contacts:
            self.dispatch('search',name=self.contacts[self.selected_id]['name'])

    def _close(self):
        if self.worker:self.worker.submit('shutdown')
        self.destroy()


_instance_mutex = None

def _single_instance() -> bool:
    global _instance_mutex
    if os.name!='nt': return True
    import ctypes
    dll=ctypes.windll.kernel32
    dll.CreateMutexW.argtypes=(ctypes.c_void_p,ctypes.c_bool,ctypes.c_wchar_p)
    dll.CreateMutexW.restype=ctypes.c_void_p
    _instance_mutex=dll.CreateMutexW(None,False,'Local\\ThayLinhZaloStandaloneManager')
    return bool(_instance_mutex) and dll.GetLastError()!=183

def main():
    if not _single_instance():
        return
    try:
        Manager(run_browser=os.getenv('ZALO_STANDALONE_UI_TEST')!='1').mainloop()
    except BaseException as exc:
        # This diagnostic contains no contact/chat/QR/private data.
        try:
            file=crm.DATA_ROOT/'startup-health.json'
            file.parent.mkdir(parents=True,exist_ok=True)
            file.write_text(json.dumps({'state':'ERROR','code':type(exc).__name__},ensure_ascii=False),encoding='utf-8')
        except Exception:pass
        try:messagebox.showerror('Zalo Personal Manager','Ứng dụng chưa khởi động được. Kiểm tra startup-health.json trong thư mục dữ liệu.')
        except Exception:pass

if __name__=='__main__':main()
