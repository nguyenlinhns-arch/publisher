"""Pure safeguards for owned Zalo Chrome sessions and contacts inventory."""
from __future__ import annotations
import re
from urllib.parse import urlparse
from dataclasses import dataclass

ALLOWED_ORIGINS = {"https://chat.zalo.me", "https://id.zalo.me"}
LOGIN_URL = "https://id.zalo.me/account?continue=https%3A%2F%2Fchat.zalo.me%2F"
CHAT_URL = "https://chat.zalo.me/"


def classify(url: str) -> str:
    try:
        p = urlparse(url)
        if p.scheme != "https" or p.username or p.password or p.port not in (None, 443):
            return "UNTRUSTED"
        if p.hostname == "chat.zalo.me":
            return "CHAT_OR_LOGIN"  # URL alone cannot confirm login
        if p.hostname == "id.zalo.me" and p.path.startswith("/account"):
            return "LOGIN"
        if p.hostname in ("www.zalo.me", "zalo.me"):
            return "MARKETING"
        return "OTHER"
    except (ValueError, TypeError):
        return "UNTRUSTED"


def summarize_view(url: str, visible_hints: list[str]) -> str:
    """Nonprivate structural labels; no QR/content and no name scraping."""
    kind = classify(url)
    if kind in ("UNTRUSTED", "OTHER", "MARKETING"):
        return kind
    text = " ".join(visible_hints).casefold()
    if kind == "LOGIN":
        return "LOGIN_QR" if any(x in text for x in ("đăng nhập qua mã qr", "quét mã qr", "scan qr")) else "LOGIN_LOADING"
    if any(x in text for x in ("đăng nhập qua mã qr", "quét mã qr")):
        return "LOGIN_QR"
    if "tìm kiếm" in text and ("danh bạ" in text or "tin nhắn" in text or "trò chuyện" in text):
        return "CHAT_READY"
    return "CHAT_UNVERIFIED"


@dataclass(frozen=True)
class Row:
    name: str
    secondary: str = ""
    labels: tuple[str, ...] = ()


def canonical(r: Row) -> tuple:
    return (r.name.strip().casefold(), r.secondary.strip().casefold(), tuple(x.casefold().strip() for x in r.labels))


def validate_page(rows, expected, height, viewport, top):
    if not isinstance(expected, int) or not 0 <= expected <= 20000:
        raise ValueError("COUNT_UNVERIFIED")
    if not isinstance(rows, list) or len(rows) > 200:
        raise ValueError("ROW_PAGE_INVALID")
    if any(not isinstance(x, Row) or not (2 <= len(x.name.strip()) <= 150) for x in rows):
        raise ValueError("INVALID_NAME")
    if any(not isinstance(x, (int, float)) for x in (height, viewport, top)) or viewport < 50 or height < viewport or top < 0:
        raise ValueError("SCROLL_UNVERIFIED")
    if len(set(map(canonical, rows))) != len(rows):
        raise ValueError("DUPLICATE_IDENTICAL_ROWS_ON_PAGE")
    return True


def merge_with_overlap(prior: list[Row], current: list[Row]) -> list[Row]:
    if not prior:
        return list(current)
    a, b = list(map(canonical, prior)), list(map(canonical, current))
    for n in range(min(len(a), len(b)), 0, -1):
        if a[-n:] == b[:n]:
            return prior + current[n:]
    raise ValueError("CONTINUITY_UNVERIFIED")


def normalize_count(v):
    if isinstance(v, int) and 0 <= v <= 20000:
        return v
    if isinstance(v, str) and re.fullmatch(r"\d{1,3}(?:[.,]\d{3})*|\d{1,5}", v):
        n = int(v.replace(".", "").replace(",", ""))
        return n if n <= 20000 else None
    return None
