"""Read-only Zalo contact CRM core. No Zalo network or send capabilities."""
from __future__ import annotations
import csv
import datetime as dt
import json
import os
import re
import sqlite3
import uuid
from collections import Counter
from pathlib import Path

BASE = Path(__file__).resolve().parent
DATA = Path(os.environ.get("ZALO_CRM_DATA_DIR", BASE / "data"))
DATA.mkdir(exist_ok=True)
DB_PATH = DATA / "contacts.sqlite3"

SEGMENTS = (
    "Chưa phân loại", "Đã nhập học", "Cựu học viên / CN cũ",
    "Đăng ký cũ", "Đang hẹn / tư vấn", "Hồ sơ theo năm",
    "Đối tác / CTV", "Liên hệ Miền Trung", "Nhóm thẻ khác", "Không liên hệ"
)
KNOWN_LABELS = {
    "Đã Nhập Học", "CN Cũ", "Đăng ký cũ", "Hẹn ra", "Loại",
    "Miền Trung", "2026.QT", "2026.T2", "2025.T9-T12", "2025.T8",
    "2025.T7", "2025.T6", "Tin nhắn từ người lạ"
}


def normalize(value):
    return " ".join(str(value or "").replace("\xa0", " ").split()).strip()


def infer_segment(name, labels):
    """Only infer from literal, observable labels/nicknames, never demographics."""
    name = normalize(name)
    labs = [normalize(x) for x in (labels or []) if normalize(x)]
    fold = {x.casefold() for x in labs}
    def has(x): return x.casefold() in fold
    if has("Loại") or has("Tin nhắn từ người lạ"):
        return "Không liên hệ", "high", "Zalo label: Loại/người lạ"
    if has("Đã Nhập Học"):
        return "Đã nhập học", "high", "Zalo label: Đã Nhập Học"
    if has("CN Cũ"):
        return "Cựu học viên / CN cũ", "high", "Zalo label: CN Cũ"
    if has("Đăng ký cũ"):
        return "Đăng ký cũ", "high", "Zalo label: Đăng ký cũ"
    if has("Hẹn ra"):
        return "Đang hẹn / tư vấn", "high", "Zalo label: Hẹn ra"
    if has("Miền Trung"):
        return "Liên hệ Miền Trung", "medium", "Zalo label: Miền Trung; chưa kết luận nơi cư trú"
    if re.search(r"\bCTV\b", name, re.I):
        return "Đối tác / CTV", "low", "Tên gợi nhớ chứa CTV; cần xác nhận"
    if re.match(r"^HS(?:20\d\d|\b)", name, re.I):
        return "Hồ sơ theo năm", "medium", "Tên gợi nhớ bắt đầu HS; chưa khẳng định nhập học"
    if labs:
        return "Nhóm thẻ khác", "low", "Có thẻ: " + ", ".join(labs[:3])
    return "Chưa phân loại", "none", "Chưa có bằng chứng phân loại"


def connect(path=DB_PATH):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    conn = sqlite3.connect(path)
    conn.row_factory = sqlite3.Row
    conn.executescript("""
        PRAGMA journal_mode=WAL;
        CREATE TABLE IF NOT EXISTS contacts (
            id TEXT PRIMARY KEY,
            name TEXT NOT NULL,
            secondary TEXT NOT NULL DEFAULT '',
            zalo_labels TEXT NOT NULL DEFAULT '[]',
            segment TEXT NOT NULL DEFAULT 'Chưa phân loại',
            segment_source TEXT NOT NULL DEFAULT 'inferred',
            confidence TEXT NOT NULL DEFAULT 'none',
            evidence TEXT NOT NULL DEFAULT '',
            consent TEXT NOT NULL DEFAULT 'unknown',
            do_not_contact INTEGER NOT NULL DEFAULT 0,
            needs_review INTEGER NOT NULL DEFAULT 1,
            notes TEXT NOT NULL DEFAULT '',
            region TEXT NOT NULL DEFAULT '',
            last_seen_scan TEXT NOT NULL DEFAULT '',
            last_updated TEXT NOT NULL DEFAULT ''
        );
        CREATE TABLE IF NOT EXISTS scans (
            scan_id TEXT PRIMARY KEY,
            started_at TEXT NOT NULL,
            expected_count INTEGER,
            seen_count INTEGER,
            complete INTEGER NOT NULL DEFAULT 0,
            method TEXT,
            error TEXT
        );
        CREATE TABLE IF NOT EXISTS scan_rows (
            scan_id TEXT NOT NULL,
            ordinal INTEGER NOT NULL,
            contact_id TEXT NOT NULL,
            PRIMARY KEY (scan_id, ordinal)
        );
        CREATE INDEX IF NOT EXISTS contacts_name ON contacts(name);
        CREATE INDEX IF NOT EXISTS contacts_segment ON contacts(segment);
        CREATE TABLE IF NOT EXISTS drafts (
            contact_id TEXT PRIMARY KEY,
            body TEXT NOT NULL,
            revision INTEGER NOT NULL DEFAULT 1,
            state TEXT NOT NULL DEFAULT 'DRAFT',
            updated_at TEXT NOT NULL
        );
    """)
    return conn


def _now():
    return dt.datetime.now(dt.timezone.utc).isoformat()


def import_scan(payload, conn):
    """Import only verified full scans; do not merge ambiguous same-name friends."""
    if not isinstance(payload, dict) or payload.get("ok") is not True or payload.get("complete") is not True:
        raise ValueError("Chưa có bản quét đầy đủ và đã xác minh; không nhập bản quét chưa hoàn tất")
    friends = payload.get("friends")
    expected = payload.get("expectedCount")
    if not isinstance(friends, list) or not isinstance(expected, int) or expected != len(friends):
        raise ValueError("Số lượng hàng không khớp số bạn bè trên Zalo")
    if not all(isinstance(f, dict) and normalize(f.get("name")) for f in friends):
        raise ValueError("Hàng bạn bè không hợp lệ")
    scan_id = payload.get("scan_id") or str(uuid.uuid4())
    if conn.execute("SELECT 1 FROM scans WHERE scan_id=?", (scan_id,)).fetchone():
        raise ValueError("Bản quét này đã được nhập trước đó")
    name_occ = Counter((normalize(f.get('name')).casefold(), normalize(f.get('secondary')).casefold()) for f in friends)
    old = conn.execute("SELECT id,name,secondary,last_seen_scan FROM contacts").fetchall()
    old_occ = Counter((normalize(f['name']).casefold(), normalize(f['secondary']).casefold()) for f in old)
    old_map = {(normalize(f['name']).casefold(), normalize(f['secondary']).casefold()):f['id'] for f in old if old_occ[(normalize(f['name']).casefold(),normalize(f['secondary']).casefold())]==1}
    now = _now()
    with conn:
        conn.execute("INSERT INTO scans VALUES (?,?,?,?,?,?,?)",(scan_id,now,expected,len(friends),1,payload.get('method','ui-automation'),None))
        for idx,f in enumerate(friends):
            name = normalize(f['name']);secondary=normalize(f.get('secondary'))
            labs=list(dict.fromkeys(normalize(x) for x in f.get('labels',[]) if normalize(x)))
            key=(name.casefold(),secondary.casefold())
            unique=name_occ[key]==1 and old_occ[key]<=1
            ident=old_map.get(key) if unique else None
            if not ident:ident=str(uuid.uuid4())
            inferred,confidence,evidence=infer_segment(name,labs)
            ambiguous=not unique
            existing=conn.execute("SELECT segment,segment_source,consent,do_not_contact,notes,region FROM contacts WHERE id=?",(ident,)).fetchone()
            manual=bool(existing and existing['segment_source']=='manual')
            final_segment=existing['segment'] if manual else inferred
            consent=existing['consent'] if existing else 'unknown'
            blocked=int(bool((existing and existing['do_not_contact']) or inferred=='Không liên hệ'))
            conn.execute("""INSERT INTO contacts(id,name,secondary,zalo_labels,segment,segment_source,confidence,evidence,consent,do_not_contact,needs_review,notes,region,last_seen_scan,last_updated)
                VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)
                ON CONFLICT(id) DO UPDATE SET name=excluded.name,secondary=excluded.secondary,zalo_labels=excluded.zalo_labels,
                segment=excluded.segment,segment_source=excluded.segment_source,confidence=excluded.confidence,evidence=excluded.evidence,
                do_not_contact=excluded.do_not_contact,needs_review=excluded.needs_review,last_seen_scan=excluded.last_seen_scan,last_updated=excluded.last_updated
                """,(ident,name,secondary,json.dumps(labs,ensure_ascii=False),final_segment,'manual' if manual else 'inferred',confidence,evidence,
                       consent,blocked,int(ambiguous or confidence not in ('high','medium')),existing['notes'] if existing else '',existing['region'] if existing else '',scan_id,now))
            conn.execute("INSERT INTO scan_rows VALUES (?,?,?)",(scan_id,idx,ident))
    return {"scan_id":scan_id,"count":len(friends),"ambiguous":sum(name_occ[k]>1 for k in name_occ for _ in range(name_occ[k]))}


def save_draft(conn, contact_id: str, body: str):
    """Durable local draft, never a send request. Byte-exact Unicode body is kept.

    Repeated saves of the same text are idempotent. Contact identity must exist
    in this app's own CRM; drafts are not Zalo conversation messages.
    """
    if not isinstance(contact_id, str) or not contact_id:
        raise ValueError('DRAFT_CONTACT_UNVERIFIED')
    if not isinstance(body, str) or not body.strip() or len(body) > 3500 or '\x00' in body:
        raise ValueError('DRAFT_CONTENT_INVALID')
    if not conn.execute('SELECT 1 FROM contacts WHERE id=?',(contact_id,)).fetchone():
        raise ValueError('DRAFT_CONTACT_NOT_FOUND')
    existing=conn.execute('SELECT body,revision FROM drafts WHERE contact_id=?',(contact_id,)).fetchone()
    if existing and existing['body']==body:
        return {'contact_id':contact_id,'revision':existing['revision'],'saved':True,'changed':False}
    revision=existing['revision']+1 if existing else 1
    with conn:
        conn.execute("""INSERT INTO drafts(contact_id,body,revision,state,updated_at)
                    VALUES(?,?,?,?,?) ON CONFLICT(contact_id) DO UPDATE SET
                    body=excluded.body,revision=excluded.revision,state=excluded.state,updated_at=excluded.updated_at""",
                    (contact_id,body,revision,'DRAFT',_now()))
    return {'contact_id':contact_id,'revision':revision,'saved':True,'changed':True}


def load_draft(conn, contact_id: str):
    """Read a local draft by stable CRM id; does not query Zalo."""
    rec=conn.execute('SELECT body,revision,state,updated_at FROM drafts WHERE contact_id=?',(contact_id,)).fetchone()
    return dict(rec) if rec else None


def edit_contact(conn, contact_id, segment=None, consent=None, do_not_contact=None, notes=None, region=None):
    fields=[]; params=[]
    if segment is not None:
        if segment not in SEGMENTS:raise ValueError('Phân loại không hợp lệ')
        fields += ['segment=?','segment_source=?','needs_review=?'];params.extend([segment,'manual',0])
    if consent is not None:
        if consent not in ('unknown','yes','no'):raise ValueError('Trạng thái đồng ý không hợp lệ')
        fields.append('consent=?');params.append(consent)
    if do_not_contact is not None:
        fields.append('do_not_contact=?');params.append(int(bool(do_not_contact)))
    if notes is not None:fields.append('notes=?');params.append(normalize(notes)[:2000])
    if region is not None:fields.append('region=?');params.append(normalize(region)[:120])
    if not fields:return
    fields.append('last_updated=?');params.append(_now())
    params.append(contact_id)
    with conn:
        cur=conn.execute('UPDATE contacts SET '+','.join(fields)+' WHERE id=?',params)
        if not cur.rowcount:raise ValueError('Không tìm thấy liên hệ')


def list_contacts(conn, q='', segment=None):
    sql='SELECT * FROM contacts WHERE 1=1';params=[]
    if q:
        sql+=' AND (name LIKE ? OR secondary LIKE ? OR notes LIKE ?)';params += ['%'+q+'%']*3
    if segment and segment!='Tất cả':sql+=' AND segment=?';params.append(segment)
    sql+=' ORDER BY name COLLATE NOCASE ASC, id ASC'
    return conn.execute(sql,params).fetchall()

TEMPLATES={
    'Đã nhập học': 'Chào {name}, tình hình học tập và sinh hoạt ở trường của em dạo này thế nào? Nếu có vấn đề cần hỗ trợ, em cứ nhắn lại cho anh nhé.',
    'Cựu học viên / CN cũ': 'Chào {name}, dạo này công việc của em thế nào? Anh hỏi thăm một chút. Khi cần hỗ trợ thông tin liên quan đến nhà trường, em cứ nhắn nhé.',
    'Đăng ký cũ': 'Chào {name}, anh Linh bên Trường Cao đẳng Than – Khoáng sản Việt Nam đây. Trước đây mình có đăng ký tìm hiểu chương trình học nghề. Nếu em vẫn quan tâm, anh có thể cập nhật thông tin để em tham khảo nhé.',
    'Đang hẹn / tư vấn': 'Chào {name}, anh Linh đây. Anh liên hệ để hỏi xem em có cần anh giải đáp thêm thông tin học nghề và việc làm không nhé.',
    'Hồ sơ theo năm': 'Chào {name}, anh Linh bên Trường Cao đẳng Than – Khoáng sản Việt Nam đây. Anh muốn hỏi thăm xem em có cần hỗ trợ thêm thông tin về học nghề và việc làm không nhé.',
    'Đối tác / CTV': 'Chào {name}, tôi muốn trao đổi thêm về khả năng phối hợp tư vấn học nghề và việc làm cho lao động địa phương. Khi nào thuận tiện, anh/chị phản hồi giúp tôi nhé.',
    'Liên hệ Miền Trung': 'Chào {name}, tôi là Linh bên Phòng Tuyển sinh Miền Trung. Khi thuận tiện, anh/chị cho tôi xin ít phút để trao đổi thông tin công việc nhé.',
}


def make_draft(contact):
    row=dict(contact)
    if row.get('do_not_contact') or row.get('consent')=='no' or row.get('segment')=='Không liên hệ':
        return {'ok':False,'reason':'Liên hệ bị loại trừ / không đồng ý nhận tin'}
    if row.get('needs_review'):
        return {'ok':False,'reason':'Cần xác minh người và phân loại trước khi soạn tin'}
    template=TEMPLATES.get(row.get('segment'))
    if not template:return {'ok':False,'reason':'Chưa đủ thông tin để tạo nội dung phù hợp'}
    name=normalize(row.get('name'))
    if not name:return {'ok':False,'reason':'Thiếu tên người nhận'}
    text=template.format(name=name)
    return {'ok':True,'text':text,'eligible_to_send':row.get('consent')=='yes',
            'warning':None if row.get('consent')=='yes' else 'Chỉ là bản nháp, chưa có xác nhận đồng ý nhận nội dung'}


def export_contacts(conn, path, segment=None):
    fields=['name','secondary','zalo_labels','segment','confidence','consent','do_not_contact','needs_review','region','notes']
    with open(path,'w',encoding='utf-8-sig',newline='') as f:
        writer=csv.writer(f);writer.writerow(fields)
        for r in list_contacts(conn,segment=segment):writer.writerow([r[k] for k in fields])


def export_draft_queue(conn,path,segment=None):
    # Deliberately exports approved one-to-one drafts only; does not transmit.
    with open(path,'w',encoding='utf-8-sig',newline='') as f:
        writer=csv.writer(f);writer.writerow(['contact_id','person','segment','draft_text','status'])
        for r in list_contacts(conn,segment=segment):
            d=make_draft(r)
            if d.get('ok') and d['eligible_to_send']:
                writer.writerow([r['id'],r['name'],r['segment'],d['text'],'REVIEW_BEFORE_INDIVIDUAL_SEND'])
