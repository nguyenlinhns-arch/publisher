"""Private CRM state separate from Zalo profile and old application; SQLite only."""
from __future__ import annotations
import os
import sqlite3
import shutil
import uuid
import datetime as dt
from contextlib import closing
from pathlib import Path


def user_roaming():
    if os.name=='nt':
        return Path(os.environ.get('APPDATA') or (Path.home()/'AppData'/'Roaming'))
    return Path.home()/'.local'/'share'

DATA_ROOT = Path(os.environ.get('ZALO_STANDALONE_DATA') or (user_roaming()/'ThayLinhZaloStandalone'))
DATA_DIR = DATA_ROOT/'crm-data'
DATA_DIR.mkdir(parents=True,exist_ok=True)
os.environ['ZALO_CRM_DATA_DIR']=str(DATA_DIR)
from core import connect, import_scan, list_contacts, edit_contact, make_draft, save_draft, load_draft, SEGMENTS  # noqa: E402

DB = DATA_DIR/'contacts.sqlite3'
LEGACY = user_roaming()/'ThayLinhZaloWebManager'/'crm-data'/'contacts.sqlite3'


def verified_sqlite_backup(from_path, dst_path):
    """Snapshot with the SQLite backup API; never copy live WAL database directly."""
    from_path=Path(from_path);dst_path=Path(dst_path)
    if not from_path.is_file():return False
    dst_path.parent.mkdir(parents=True,exist_ok=True)
    if dst_path.exists():return False
    tmp=dst_path.with_suffix('.installing')
    if tmp.exists():raise RuntimeError('PENDING_SQLITE_BACKUP')
    try:
        with closing(sqlite3.connect(f'file:{from_path.as_posix()}?mode=ro',uri=True)) as original:
            with closing(sqlite3.connect(tmp)) as target:
                original.backup(target)
                if target.execute('PRAGMA integrity_check').fetchone()[0]!='ok':
                    raise RuntimeError('SQLITE_BACKUP_INVALID')
        tmp.replace(dst_path)
        return True
    finally:
        if tmp.exists():tmp.unlink()


def initialize_db():
    verified_sqlite_backup(LEGACY,DB)
    with closing(connect()) as c:
        c.execute('SELECT COUNT(*) FROM contacts').fetchone()
    return DB


def load_contacts(query='',segment='Tất cả',limit=500):
    with closing(connect()) as c:
        rows=list_contacts(c,query,segment)
        return [dict(r) for r in rows[:limit]],len(rows)


def update_contact(contact_id,segment,consent,blocked,notes,region):
    with closing(connect()) as c:
        edit_contact(c,contact_id,segment=segment,consent=consent,
                     do_not_contact=blocked,notes=notes,region=region)


def add_manual_contact(name):
    name=' '.join(str(name).split())
    if not 2<=len(name)<=150:raise ValueError('INVALID_NAME')
    with closing(connect()) as c:
        # Must resolve duplicate people manually; no merging by display name.
        exists=c.execute('SELECT COUNT(*) FROM contacts WHERE name=? COLLATE NOCASE',(name,)).fetchone()[0]
        if exists:raise ValueError('NAME_DUPLICATE_NEEDS_REVIEW')
        uid=str(uuid.uuid4())
        now=dt.datetime.now(dt.timezone.utc).isoformat()
        with c:
            c.execute('''INSERT INTO contacts(id,name,secondary,zalo_labels,segment,segment_source,confidence,evidence,consent,do_not_contact,needs_review,notes,region,last_seen_scan,last_updated)
                       VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)''',
                (uid,name,'','[]','Chưa phân loại','manual','none','Người dùng nhập; chưa đối chiếu Zalo','unknown',0,1,'','','',now))
    return uid


def import_full_scan(payload):
    if not payload.get('ok') or not payload.get('complete') or payload.get('expectedCount') != payload.get('seenCount'):
        raise ValueError('SCAN_UNVERIFIED')
    # Backup right before import, after the final DOM page is verified.
    backup=DATA_DIR/'backups'/('before-scan-'+dt.datetime.now().strftime('%Y%m%d-%H%M%S')+'.sqlite3')
    # Backup of existing DB must be created, even when scan is empty.
    backup.parent.mkdir(parents=True,exist_ok=True)
    with closing(connect()) as c:
        with closing(sqlite3.connect(backup)) as to:
            c.backup(to)
            if to.execute('PRAGMA integrity_check').fetchone()[0]!='ok':raise RuntimeError('BACKUP_INVALID')
        payload['scan_id']=str(uuid.uuid4())
        receipt=import_scan(payload,c)
    return receipt


def store_draft(contact_id,body):
    with closing(connect()) as c:
        return save_draft(c,contact_id,body)


def load_saved_draft(contact_id):
    with closing(connect()) as c:
        return load_draft(c,contact_id)
