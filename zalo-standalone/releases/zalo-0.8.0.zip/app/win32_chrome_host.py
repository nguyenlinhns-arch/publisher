"""Attach *only* the Zalo-owned Google Chrome app window to a Tk pane.

This is a Windows window-management adapter, not an Electron/WebView
substitute and not a Zalo API. Fail closed on missing process proof or HWND
ambiguity. No cookies, network inspection, hidden Zalo endpoints or secrets.
"""
from __future__ import annotations
import ctypes
from ctypes import wintypes
import os
from pathlib import Path, PureWindowsPath
import re

CHAT_MARKER = '--app=https://chat.zalo.me/'
PROFILE_ARG = '--user-data-dir='


def trusted_chrome_command(command: str | None, expected_profile: str | Path, executable: str | None) -> bool:
    """Only the locally owned Chrome app profile may be reparented.

    Do not accidentally embed Chrome from the MXH publisher or a different
    account, even when both windows share a Zalo title.
    """
    if not isinstance(command, str) or not isinstance(executable, str):
        return False
    if PureWindowsPath(executable).name.casefold() != 'chrome.exe':
        return False
    normalized = command.replace('"', '').replace('\\', '/').casefold()
    profile = str(Path(expected_profile)).replace('\\', '/').casefold().rstrip('/')
    if not profile or 'mxhvideopublisher' in profile:
        return False
    arg = re.escape(PROFILE_ARG + profile)
    app = re.escape(CHAT_MARKER)
    return (re.search(arg + r'(?=\s|$)', normalized) is not None
            and re.search(app + r'(?=\s|$)', normalized) is not None)


if os.name == 'nt':
    from ctypes import windll
    U = windll.user32
    K = windll.kernel32
    NT = windll.ntdll
    HWND = wintypes.HWND
    LONG_PTR = ctypes.c_ssize_t
    DWORD = wintypes.DWORD
    PROCESS_QUERY_LIMITED_INFORMATION = 0x1000
    PROCESS_VM_READ = 0x0010
    GWL_STYLE = -16
    GWL_EXSTYLE = -20
    WS_CHILD = 0x40000000
    WS_POPUP = 0x80000000
    WS_CAPTION = 0x00C00000
    WS_THICKFRAME = 0x00040000
    WS_EX_APPWINDOW = 0x00040000
    SWP_NOZORDER = 0x0004
    SWP_FRAMECHANGED = 0x0020
    SWP_SHOWWINDOW = 0x0040
    GW_OWNER = 4
    PROCESS_COMMAND_LINE_INFORMATION = 60
    WINFUNCTYPE = ctypes.WINFUNCTYPE

    class _UNICODE_STRING(ctypes.Structure):
        _fields_ = [('Length', wintypes.USHORT),
                    ('MaximumLength', wintypes.USHORT),
                    ('Buffer', ctypes.c_void_p)]

    K.OpenProcess.argtypes = (DWORD, wintypes.BOOL, DWORD)
    K.OpenProcess.restype = wintypes.HANDLE
    K.CloseHandle.argtypes = (wintypes.HANDLE,)
    K.QueryFullProcessImageNameW.argtypes = (wintypes.HANDLE, DWORD, wintypes.LPWSTR, ctypes.POINTER(DWORD))
    K.QueryFullProcessImageNameW.restype = wintypes.BOOL
    NT.NtQueryInformationProcess.argtypes = (wintypes.HANDLE, DWORD, ctypes.c_void_p, DWORD, ctypes.POINTER(DWORD))
    NT.NtQueryInformationProcess.restype = wintypes.LONG
    U.GetWindowThreadProcessId.argtypes = (HWND, ctypes.POINTER(DWORD))
    U.GetWindowThreadProcessId.restype = DWORD
    U.IsWindow.argtypes = (HWND,)
    U.IsWindow.restype = wintypes.BOOL
    U.IsWindowVisible.argtypes = (HWND,)
    U.IsWindowVisible.restype = wintypes.BOOL
    U.GetWindow.argtypes = (HWND, wintypes.UINT)
    U.GetWindow.restype = HWND
    U.GetWindowTextLengthW.argtypes = (HWND,)
    U.GetWindowTextLengthW.restype = ctypes.c_int
    U.GetWindowTextW.argtypes = (HWND, wintypes.LPWSTR, ctypes.c_int)
    U.GetWindowTextW.restype = ctypes.c_int
    U.GetClassNameW.argtypes = (HWND, wintypes.LPWSTR, ctypes.c_int)
    U.GetClassNameW.restype = ctypes.c_int
    U.GetParent.argtypes = (HWND,)
    U.GetParent.restype = HWND
    U.SetParent.argtypes = (HWND, HWND)
    U.SetParent.restype = HWND
    U.GetWindowLongPtrW.argtypes = (HWND, ctypes.c_int)
    U.GetWindowLongPtrW.restype = LONG_PTR
    U.SetWindowLongPtrW.argtypes = (HWND, ctypes.c_int, LONG_PTR)
    U.SetWindowLongPtrW.restype = LONG_PTR
    U.SetWindowPos.argtypes = (HWND, HWND, ctypes.c_int, ctypes.c_int, ctypes.c_int, ctypes.c_int, wintypes.UINT)
    U.SetWindowPos.restype = wintypes.BOOL
    U.MoveWindow.argtypes = (HWND, ctypes.c_int, ctypes.c_int, ctypes.c_int, ctypes.c_int, wintypes.BOOL)
    U.MoveWindow.restype = wintypes.BOOL
    U.ShowWindow.argtypes = (HWND, ctypes.c_int)
    EnumProc = WINFUNCTYPE(wintypes.BOOL, HWND, wintypes.LPARAM)
    U.EnumWindows.argtypes = (EnumProc, wintypes.LPARAM)
    U.EnumWindows.restype = wintypes.BOOL


def _own_chrome_info(pid: int) -> tuple[str | None, str | None]:
    if os.name != 'nt' or not pid:
        return None, None
    handle = K.OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION | PROCESS_VM_READ, False, pid)
    if not handle:
        return None, None
    try:
        sz = DWORD(32768)
        path = ctypes.create_unicode_buffer(sz.value)
        if not K.QueryFullProcessImageNameW(handle, 0, path, ctypes.byref(sz)):
            return None, None
        executable = path.value
        # Native Windows process command-line query; avoid WMI, PowerShell,
        # clipboard or querying Chrome cookies. Never log the full string.
        for size in (4096, 16384, 65536):
            buf = ctypes.create_string_buffer(size)
            needed = DWORD(0)
            status = NT.NtQueryInformationProcess(handle, PROCESS_COMMAND_LINE_INFORMATION,
                                                   buf, size, ctypes.byref(needed))
            if status == 0:
                u = ctypes.cast(buf, ctypes.POINTER(_UNICODE_STRING)).contents
                begin = ctypes.addressof(buf)
                if (u.Length % 2 != 0 or u.Length > size or
                        not begin <= (u.Buffer or 0) <= begin + size - u.Length):
                    return None, None
                return executable, ctypes.wstring_at(u.Buffer, u.Length // 2)
        return executable, None
    finally:
        K.CloseHandle(handle)


def find_owned_chrome_window(profile: Path) -> tuple[int | None, str]:
    """Find a unique top-level app window with an exact signed-off profile."""
    if os.name != 'nt':
        return None, 'WINDOWS_REQUIRED'
    matches = []
    checked_pids = {}

    def visit(hwnd, _):
        if not U.IsWindowVisible(hwnd) or U.GetWindow(hwnd, GW_OWNER):
            return True
        cls = ctypes.create_unicode_buffer(128)
        U.GetClassNameW(hwnd, cls, len(cls))
        if cls.value != 'Chrome_WidgetWin_1':
            return True
        title_len = U.GetWindowTextLengthW(hwnd)
        if title_len < 1 or title_len > 1024:
            return True
        pid = DWORD(0)
        U.GetWindowThreadProcessId(hwnd, ctypes.byref(pid))
        if not pid.value:
            return True
        if pid.value not in checked_pids:
            exe, command = _own_chrome_info(pid.value)
            checked_pids[pid.value] = trusted_chrome_command(command, profile, exe)
        if checked_pids[pid.value]:
            matches.append(int(hwnd))
        return True

    callback = EnumProc(visit)
    U.EnumWindows(callback, 0)
    if len(matches) != 1:
        return None, 'CHROME_WINDOW_AMBIGUOUS' if matches else 'CHROME_WINDOW_NOT_READY'
    return matches[0], 'VERIFIED'


class ChromeWindowHost:
    """Parent a verified app-mode HWND inside a real Tk frame.

    The Tk root and Chrome renderer remain separate processes. Failure never
    causes a guessed foreign window to be captured. The original HWND style is
    restored when the app shuts down or detaches.
    """
    def __init__(self, frame, profile: Path):
        self.frame = frame
        self.profile = Path(profile)
        self.hwnd = None
        self.old_style = None
        self.old_exstyle = None
        self.last_size = (0, 0)
        self.reason = 'CHROME_WINDOW_NOT_READY'

    @property
    def attached(self):
        return bool(self.hwnd and os.name == 'nt' and U.IsWindow(self.hwnd)
                    and U.GetParent(self.hwnd) == self.frame.winfo_id())

    def attach(self):
        if os.name != 'nt':
            self.reason = 'WINDOWS_REQUIRED'
            return False
        if self.attached:
            self.resize()
            return True
        if self.hwnd:
            self.hwnd = None
        found, detail = find_owned_chrome_window(self.profile)
        if not found:
            self.reason = detail
            return False
        parent = self.frame.winfo_id()
        if not U.IsWindow(parent):
            self.reason = 'CHROME_HOST_NOT_READY'
            return False
        old_style = U.GetWindowLongPtrW(found, GWL_STYLE)
        old_exstyle = U.GetWindowLongPtrW(found, GWL_EXSTYLE)
        # Switch to child style BEFORE SetParent per Win32 windowing contract.
        style = (old_style & ~WS_POPUP & ~WS_CAPTION & ~WS_THICKFRAME) | WS_CHILD
        U.SetWindowLongPtrW(found, GWL_STYLE, style)
        U.SetWindowLongPtrW(found, GWL_EXSTYLE, old_exstyle & ~WS_EX_APPWINDOW)
        U.SetParent(found, parent)
        # For a previous top-level window, SetParent may return NULL even on
        # success. The verified postcondition is the actual parent HWND.
        if U.GetParent(found) != parent:
            U.SetWindowLongPtrW(found, GWL_STYLE, old_style)
            U.SetWindowLongPtrW(found, GWL_EXSTYLE, old_exstyle)
            self.reason = 'WINDOWS_REPARENT_REJECTED'
            return False
        self.hwnd = found
        self.old_style, self.old_exstyle = old_style, old_exstyle
        self.reason = 'ATTACHED'
        self.resize(force=True)
        return True

    def resize(self, force=False):
        if not self.attached:
            return False
        w = max(1, self.frame.winfo_width())
        h = max(1, self.frame.winfo_height())
        if not force and (w, h) == self.last_size:
            return True
        self.last_size = (w, h)
        return bool(U.SetWindowPos(self.hwnd, 0, 0, 0, w, h,
                                   SWP_NOZORDER | SWP_FRAMECHANGED | SWP_SHOWWINDOW))

    def detach(self):
        if os.name != 'nt' or not self.hwnd:
            return
        hwnd = self.hwnd
        self.hwnd = None
        if not U.IsWindow(hwnd):
            return
        U.SetParent(hwnd, 0)
        if self.old_style is not None:
            U.SetWindowLongPtrW(hwnd, GWL_STYLE, self.old_style)
        if self.old_exstyle is not None:
            U.SetWindowLongPtrW(hwnd, GWL_EXSTYLE, self.old_exstyle)
        U.SetWindowPos(hwnd, 0, 620, 60, 1100, 840,
                        SWP_NOZORDER | SWP_FRAMECHANGED | SWP_SHOWWINDOW)
