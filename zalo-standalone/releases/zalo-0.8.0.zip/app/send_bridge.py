"""Fail-closed one-to-one Zalo Web sending through the visible UI only.

No Zalo API, token/cookie extraction or messaging automation without the
account owner's per-message, per-recipient approval. This module holds no
connection secrets and never records plaintext outgoing text.
"""
from __future__ import annotations
import re
from urllib.parse import urlparse


def lookup_kind(query: str) -> str:
    clean=''.join(str(query).split())
    if re.fullmatch(r'(?:\+84|0)\d{9,10}',clean):
        return 'PHONE'
    if 2<=len(query.strip())<=140 and not any(x in query for x in '\r\n\x00'):
        return 'NAME'
    raise ValueError('LOOKUP_INVALID')


def safe_recipient(display: str) -> str:
    """Recipient is an explicitly visible composer identity, never guessed."""
    if not isinstance(display,str):
        raise ValueError('RECIPIENT_NOT_VERIFIED')
    if any(x in display for x in '\r\n\x00<>'):
        raise ValueError('RECIPIENT_NOT_VERIFIED')
    cleaned=' '.join(display.replace('\u00a0',' ').split())
    if not 2<=len(cleaned)<=140 or any(x in cleaned for x in '\r\n\x00<>'):
        raise ValueError('RECIPIENT_NOT_VERIFIED')
    return cleaned


# The only Zalo text read is the composer hint for the *currently selected*
# conversation. Never scan chat history or private API responses to get names.
RECIPIENT_PROBE_JS=r"""() => {
const visible=e=>{if(!e)return false;const r=e.getBoundingClientRect(),s=getComputedStyle(e);
 return r.width>0&&r.height>0&&s.display!=='none'&&s.visibility!=='hidden'};
const containers=[...document.querySelectorAll('#chat-input-container-id')].filter(visible);
const editors=[...document.querySelectorAll('#richInput')].filter(visible);
if(containers.length!==1||editors.length!==1)return {ok:false,code:'COMPOSER_NOT_UNIQUE'};
const editor=editors[0],container=containers[0];
if(!container.contains(editor)||!editor.isContentEditable)return {ok:false,code:'COMPOSER_NOT_READY'};
const attrs=[];
for(const node of [container,editor,...container.querySelectorAll('[placeholder],[aria-label],[data-placeholder]')]){
 for(const key of ['placeholder','aria-label','data-placeholder']){
  const t=node.getAttribute(key);if(t&&t.length<220)attrs.push(t.trim());
 }
}
const leaves=[...container.querySelectorAll('span,div,p')].filter(visible)
 .filter(el=>el.children.length===0).map(el=>(el.textContent||'').trim()).filter(x=>x.length<220);
const hints=[...new Set([...attrs,...leaves])].map(t=>t.replace(/\s+/g,' '))
 .filter(t=>/^Nhập\s*@?,?\s*tin nhắn tới\s+.+/i.test(t));
if(hints.length!==1)return {ok:false,code:'RECIPIENT_HINT_NOT_UNIQUE'};
const matched=hints[0].match(/^Nhập\s*@?,?\s*tin nhắn tới\s+(.+)$/i);
if(!matched)return {ok:false,code:'RECIPIENT_HINT_MISSING'};
const recipient=matched[1].trim();
if(recipient.length<2||recipient.length>140)return {ok:false,code:'RECIPIENT_INVALID'};
return {ok:true,recipient};
}"""


# This intentionally requires an outgoing-specific DOM selector. A matching
# text elsewhere in the conversation is never treated as a delivery receipt.
OUTGOING_PROBE_JS=r"""(expected) => {
const selectors='[data-testid="outgoing-message"],[data-direction="outgoing"],'+
 '[data-message-direction="outgoing"],.msg-right,.message-sent';
const own=[...document.querySelectorAll(selectors)];
const matches=own.filter(el=>el.getBoundingClientRect().height>0)
 .filter(el=>(el.innerText||'').trim()===expected);
return {confirmed:matches.length>0};
}"""


def probe_recipient(page) -> str:
    if page.url.split('?',1)[0].rstrip('/')!='https://chat.zalo.me':
        raise ValueError('CHAT_VIEW_REQUIRED')
    data=page.evaluate(RECIPIENT_PROBE_JS)
    if not isinstance(data,dict) or data.get('ok') is not True:
        code=data.get('code','RECIPIENT_NOT_VERIFIED') if isinstance(data,dict) else 'RECIPIENT_NOT_VERIFIED'
        if not re.fullmatch(r'[A-Z0-9_]{3,80}',str(code)):
            code='RECIPIENT_NOT_VERIFIED'
        raise ValueError(code)
    return safe_recipient(data['recipient'])


def compose_and_send_once(page, recipient: str, body: str, wait=lambda t:None):
    """Called only after owner's explicit confirmation and durable send-intent.

    One verified Enter. No retry, even after timeout. Not checking private APIs.
    """
    if not isinstance(body,str) or not body.strip() or len(body)>3500 or '\x00' in body:
        raise ValueError('MESSAGE_INVALID')
    recipient=safe_recipient(recipient)
    current=probe_recipient(page)
    if current!=recipient:
        raise ValueError('RECIPIENT_CHANGED')
    edit=page.locator('#richInput')
    if edit.count()!=1 or not edit.is_visible() or not edit.evaluate('(e)=>e.isContentEditable'):
        raise ValueError('COMPOSER_NOT_READY')
    edit.fill(body)
    after=edit.evaluate('(e)=>e.innerText')
    if after.replace('\r\n','\n').rstrip('\n') != body.replace('\r\n','\n').rstrip('\n'):
        raise ValueError('COMPOSER_READBACK_MISMATCH')
    if probe_recipient(page)!=recipient:
        raise ValueError('RECIPIENT_CHANGED')
    edit.press('Enter')             # precisely one attempt, no blind retries
    wait(1)
    try:
        delivered=bool(page.evaluate(OUTGOING_PROBE_JS,body).get('confirmed'))
    except Exception:
        delivered=False
    return 'SENT_VERIFIED' if delivered else 'UNKNOWN'
