"""Zalo Personal Manager 0.8.0 — single-window CRM + genuine Chrome host.

Only genuine Google Chrome renders chat.zalo.me. The local Tk UI owns CRM and
is never granted the Zalo page's credentials. No Hub/MXH/Flow2 integration.
"""
from __future__ import annotations
import json
import os
import queue
import threading
import subprocess
import time
import tkinter as tk
from pathlib import Path
from tkinter import ttk, messagebox, simpledialog

import crm_runtime as crm
from core import make_draft, SEGMENTS
from browser_controller import BrowserWorker, chrome_binary
from win32_chrome_host import ChromeWindowHost
from auto_update import installed_launcher, idle_seconds, check_update_background, newer_version_ready, read_update_status

VERSION='0.8.0'
INK='#122033';BG='#eef4fa';NAVY='#123f7d';WHITE='#ffffff';MUTED='#66788d';GREEN='#087b64'


def contact_permission(row:dict)->bool:
    return row.get('consent')=='yes' and not row.get('do_not_contact') and not row.get('needs_review')


class Manager(tk.Tk):
    def __init__(self, run_browser=True):
        super().__init__()
        self.title(f'Zalo Personal Manager — Chrome độc lập v{VERSION}')
        sw,sh=self.winfo_screenwidth(),self.winfo_screenheight()
        ww=min(sw-65,1690) if sw>1100 else max(970,sw-25)
        hh=min(sh-80,950) if sh>760 else max(670,sh-38)
        self.geometry(f'{ww}x{hh}+30+35')
        self.minsize(960,620)
        self.configure(bg=BG)
        self.events=queue.Queue()
        self.worker=None
        self.contacts={}
        self.selected_id=None
        self.last_draft=''
        self.scan_in_progress=False
        self.update_check_busy=False
        self.last_update_checked_at=0.0
        self.new_version_ready=None
        self.restarting_for_update=False
        self.segment=tk.StringVar(value='Tất cả')
        self.search_var=tk.StringVar()
        self.lookup_var=tk.StringVar()
        self.recipient_display=tk.StringVar(value='Chưa xác minh người nhận')
        self.chrome_host_status=tk.StringVar(value='Đang chuẩn bị Chrome Web trong cùng cửa sổ...')
        self.pending_send=None
        self.send_in_progress=False
        self.embedded=False
        self.state_label=tk.StringVar(value='Chưa mở Chrome riêng')
        self.scan_label=tk.StringVar(value='Danh bạ: chưa quét. Mở mục Danh sách bạn bè trên Zalo trước.')
        self.people_label=tk.StringVar(value='0 liên hệ CRM')
        self.selected_name=tk.StringVar(value='Chọn một liên hệ từ danh sách')
        self.person_segment=tk.StringVar(value='Chưa phân loại')
        self.person_consent=tk.StringVar(value='unknown')
        self.person_blocked=tk.BooleanVar(value=False)
        self.person_region=tk.StringVar()
        self._init_style()
        self._build()
        try:
            crm.initialize_db()
            self.refresh_contacts()
        except Exception as exc:
            self.after(50,lambda e=str(exc):messagebox.showerror('Cơ sở dữ liệu',e))
        self.search_var.trace_add('write',lambda *a:self.after(150,self.refresh_contacts))
        self.protocol('WM_DELETE_WINDOW',self._close)
        if run_browser:
            root=Path(os.environ.get('LOCALAPPDATA',str(Path.home()/'.local'/'share')))/'ThayLinhZaloStandalone'
            # Chrome starts at an owned temporary position before being reparented
            # into the app's right pane. Never share the Flow2 ChromeProfile.
            self.chrome_host=ChromeWindowHost(self.chrome_frame,root/'ChromeProfile')
            w=max(850,int(self.winfo_screenwidth()*.61))
            h=max(600,self.winfo_screenheight()-130)
            self.worker=BrowserWorker(root,self.events,viewport=(500,65,w,h))
            self.worker.start()
        self.after(250,self._poll)
        self.after(100,self._publish_startup_ready)
        if run_browser:
            # Unattended check starts after the UI is ready and the owner is idle.
            self.after(90_000,self._auto_update_tick)
            self.after(1300,self._embed_tick)


    def _publish_startup_ready(self):
        try:
            file=crm.DATA_ROOT/'startup-health.json'
            file.parent.mkdir(parents=True,exist_ok=True)
            temporary=file.with_suffix('.tmp')
            temporary.write_text(json.dumps({'state':'READY','version':VERSION,'pid':os.getpid()},
                  ensure_ascii=False),encoding='utf-8')
            temporary.replace(file)
        except OSError:pass

    def _init_style(self):
        sty=ttk.Style(self)
        try:sty.theme_use('clam')
        except tk.TclError:pass
        sty.configure('TFrame',background=BG)
        sty.configure('TLabel',background=BG,foreground=INK,font=('Segoe UI',10))
        sty.configure('Header.TLabel',font=('Segoe UI',17,'bold'),foreground=NAVY)
        sty.configure('Sub.TLabel',foreground=MUTED,font=('Segoe UI',9))
        sty.configure('TLabelframe',background=WHITE,bordercolor='#d5dfeb')
        sty.configure('TLabelframe.Label',font=('Segoe UI',10,'bold'),foreground=NAVY,background=WHITE)
        sty.configure('Treeview',background=WHITE,foreground=INK,fieldbackground=WHITE,rowheight=29,font=('Segoe UI',9))
        sty.configure('Treeview.Heading',background='#dbe7f5',font=('Segoe UI',9,'bold'))
        sty.configure('TButton',padding=(10,7),font=('Segoe UI',9))
        sty.configure('Primary.TButton',background=NAVY,foreground=WHITE)
        sty.map('Primary.TButton',background=[('active','#2560a8')])
        sty.configure('TCombobox',padding=3)

    def _btn(self,parent,text,command,primary=False):
        return ttk.Button(parent,text=text,command=command,style='Primary.TButton' if primary else 'TButton')

    def _build(self):
        """One true desktop window: left CRM, right *owned Chrome HWND*.

        This is a real ttk.Panedwindow, not a visual mockup, screenshot or two
        floating windows positioned next to each other.
        """
        head=ttk.Frame(self,padding=(16,12,16,8))
        head.pack(fill='x')
        hr=ttk.Frame(head);hr.pack(fill='x')
        ttk.Label(hr,text='ZALO PERSONAL MANAGER',style='Header.TLabel').pack(side='left')
        ttk.Label(hr,text='v'+VERSION,style='Sub.TLabel').pack(side='right',padx=(12,2))
        ttk.Label(head,text='Một cửa sổ • Chrome Web thật • CRM độc lập • Không liên quan luồng 2',
                  style='Sub.TLabel').pack(anchor='w',pady=(2,0))

        statuses=ttk.Frame(self,padding=(17,1,17,8));statuses.pack(fill='x')
        ttk.Label(statuses,text='Zalo Web:',style='Sub.TLabel').pack(side='left')
        ttk.Label(statuses,textvariable=self.state_label).pack(side='left',padx=(5,23))
        ttk.Label(statuses,text='Ghép khung:',style='Sub.TLabel').pack(side='left')
        ttk.Label(statuses,textvariable=self.chrome_host_status,style='Sub.TLabel').pack(side='left',padx=6)

        toolbar=ttk.Frame(self,padding=(16,4,16,10));toolbar.pack(fill='x')
        self._btn(toolbar,'Mở Zalo',lambda:self.dispatch('open'),True).pack(side='left',padx=(0,5))
        self._btn(toolbar,'Kiểm tra phiên',lambda:self.dispatch('session')).pack(side='left',padx=(0,5))
        self._btn(toolbar,'Cập nhật',self.check_update_now).pack(side='left',padx=(0,15))
        ttk.Label(toolbar,text='Tên / SĐT:').pack(side='left')
        ttk.Entry(toolbar,textvariable=self.lookup_var,width=27).pack(side='left',padx=(7,5))
        self._btn(toolbar,'Tìm trên Zalo',self.search_lookup).pack(side='left',padx=(0,5))
        self._btn(toolbar,'Kiểm tra người nhận',self.verify_recipient).pack(side='left',padx=(0,5))
        self._btn(toolbar,'Gửi tin nhắn',self.send_from_app,True).pack(side='right')

        self.panes=ttk.Panedwindow(self,orient='horizontal')
        self.panes.pack(fill='both',expand=True,padx=11,pady=(0,8))
        left=ttk.Frame(self.panes);right=ttk.Frame(self.panes)
        self.panes.add(left,weight=4);self.panes.add(right,weight=7)
        self.after(300,self._initial_split)
        # Tall CRM forms stay scrollable without affecting the Chrome viewport.
        left_canvas=tk.Canvas(left,bg=BG,highlightthickness=0,bd=0)
        left_scroll=ttk.Scrollbar(left,orient='vertical',command=left_canvas.yview)
        left_canvas.configure(yscrollcommand=left_scroll.set)
        left_canvas.pack(side='left',fill='both',expand=True)
        left_scroll.pack(side='right',fill='y')
        form=ttk.Frame(left_canvas)
        window_id=left_canvas.create_window((0,0),window=form,anchor='nw')
        form.bind('<Configure>',lambda _e:left_canvas.configure(scrollregion=left_canvas.bbox('all')))
        left_canvas.bind('<Configure>',lambda e:left_canvas.itemconfigure(window_id,width=e.width))
        def _wheel(e):
            left_canvas.yview_scroll(int(-e.delta/120),'units')
        left_canvas.bind('<Enter>',lambda _:left_canvas.bind_all('<MouseWheel>',_wheel))
        left_canvas.bind('<Leave>',lambda _:left_canvas.unbind_all('<MouseWheel>'))

        self.crm_controls=ttk.LabelFrame(form,text='Quản lý liên hệ (CRM)',padding=(12,9))
        self.crm_controls.pack(fill='x',padx=(0,7),pady=(2,8))
        top=ttk.Frame(self.crm_controls);top.pack(fill='x')
        ttk.Label(top,textvariable=self.people_label,style='Sub.TLabel').pack(side='left')
        self._btn(top,'+ Thêm liên hệ',self.add_contact).pack(side='right')
        search=ttk.Frame(self.crm_controls);search.pack(fill='x',pady=(10,7))
        ttk.Entry(search,textvariable=self.search_var).pack(side='left',fill='x',expand=True,padx=(0,7))
        ttk.Combobox(search,textvariable=self.segment,values=['Tất cả',*SEGMENTS],state='readonly',width=18).pack(side='right')
        self.segment.trace_add('write',lambda *a:self.refresh_contacts())
        table=ttk.Frame(self.crm_controls);table.pack(fill='both',expand=True)
        self.tree=ttk.Treeview(table,columns=('name','segment'),show='headings',selectmode='browse',height=11)
        self.tree.heading('name',text='Tên liên hệ');self.tree.heading('segment',text='Nhóm / phân loại')
        self.tree.column('name',width=185,anchor='w',stretch=True)
        self.tree.column('segment',width=165,anchor='w',stretch=True)
        scr=ttk.Scrollbar(table,orient='vertical',command=self.tree.yview)
        self.tree.configure(yscrollcommand=scr.set)
        self.tree.pack(side='left',fill='both',expand=True);scr.pack(side='right',fill='y')
        self.tree.bind('<<TreeviewSelect>>',self.select_contact)

        scan=ttk.LabelFrame(form,text='Danh bạ Zalo (chỉ đọc)',padding=(12,9))
        scan.pack(fill='x',padx=(0,7),pady=(0,8))
        sbuttons=ttk.Frame(scan);sbuttons.pack(fill='x')
        self._btn(sbuttons,'Kiểm tra',lambda:self.dispatch('probe')).pack(side='left',padx=(0,4))
        self._btn(sbuttons,'Quét đầy đủ',lambda:self.dispatch('scan')).pack(side='left',padx=(0,4))
        self._btn(sbuttons,'Dừng',lambda:self.dispatch('cancel_scan')).pack(side='left')
        ttk.Label(scan,textvariable=self.scan_label,style='Sub.TLabel',wraplength=430).pack(anchor='w',pady=(7,0))

        edit=ttk.LabelFrame(form,text='Hồ sơ liên hệ và bản nháp',padding=(12,9))
        edit.pack(fill='x',padx=(0,7),pady=(0,6))
        ttk.Label(edit,textvariable=self.selected_name,font=('Segoe UI',10,'bold'),wraplength=430).pack(anchor='w')
        fields=ttk.Frame(edit);fields.pack(fill='x',pady=(9,5))
        ttk.Label(fields,text='Nhóm:').grid(row=0,column=0,sticky='w')
        ttk.Combobox(fields,textvariable=self.person_segment,values=SEGMENTS,state='readonly',width=22).grid(row=0,column=1,sticky='w',padx=7)
        ttk.Label(fields,text='Đồng ý:').grid(row=1,column=0,sticky='w',pady=6)
        ttk.Combobox(fields,textvariable=self.person_consent,values=['unknown','yes','no'],state='readonly',width=14).grid(row=1,column=1,sticky='w',padx=7,pady=6)
        ttk.Checkbutton(edit,text='Không liên hệ',variable=self.person_blocked).pack(anchor='w')
        ttk.Label(edit,text='Khu vực / nơi ở (nếu được xác minh):',style='Sub.TLabel').pack(anchor='w',pady=(6,0))
        ttk.Entry(edit,textvariable=self.person_region).pack(fill='x',pady=(3,4))
        ttk.Label(edit,text='Ghi chú:',style='Sub.TLabel').pack(anchor='w')
        self.notes=tk.Text(edit,height=3,wrap='word',relief='solid',bd=1,font=('Segoe UI',9))
        self.notes.pack(fill='x',pady=(3,6))
        actions=ttk.Frame(edit);actions.pack(fill='x')
        self._btn(actions,'Lưu hồ sơ',self.save_profile,True).pack(side='left',padx=(0,5))
        self._btn(actions,'Tìm trên Zalo',self.find_on_zalo).pack(side='left',padx=(0,5))
        self._btn(actions,'Tạo bản nháp',self.generate_draft).pack(side='left')
        ttk.Label(edit,text='Tin nhắn (kiểm tra người nhận trước khi gửi):',style='Sub.TLabel').pack(anchor='w',pady=(9,0))
        self.draft=tk.Text(edit,height=5,wrap='word',relief='solid',bd=1,font=('Segoe UI',9))
        self.draft.pack(fill='x',pady=(4,6))
        draft_buttons=ttk.Frame(edit);draft_buttons.pack(fill='x')
        self._btn(draft_buttons,'Lưu nháp',self.save_draft,True).pack(side='left',padx=(0,6))
        self._btn(draft_buttons,'Sao chép',self.copy_draft).pack(side='left',padx=(0,6))
        self._btn(draft_buttons,'Gửi tin...',self.send_from_app).pack(side='right')
        ttk.Label(edit,textvariable=self.recipient_display,style='Sub.TLabel',wraplength=430).pack(anchor='w',pady=(8,0))

        # THE RIGHT HALF IS A NATIVE CHILD WINDOW OF THIS TK TOPLEVEL,
        # not a preview/screenshot/webp and not a second floating desktop app.
        right_head=ttk.Frame(right,padding=(8,7,7,8));right_head.pack(fill='x')
        ttk.Label(right_head,text='Zalo Web chính thức — Chrome riêng',font=('Segoe UI',11,'bold')).pack(side='left')
        self._btn(right_head,'Gắn lại Chrome',self._try_embed).pack(side='right')
        self.chrome_frame=ttk.Frame(right)
        self.chrome_frame.pack(fill='both',expand=True,padx=(3,3),pady=(0,3))
        self.browser_placeholder=ttk.Label(self.chrome_frame,
             text='Đang mở Chrome thật trong khung Zalo...\nNếu Chrome chưa hiện, bấm “Gắn lại Chrome”.',
             style='Sub.TLabel',justify='center')
        self.browser_placeholder.place(relx=.5,rely=.45,anchor='center')
        self.chrome_frame.bind('<Configure>',self._chrome_resized)
        footer=ttk.Frame(self,padding=(14,1,14,8));footer.pack(fill='x')
        ttk.Label(footer,text='Một cửa sổ • Không gửi tự động • Không dùng Zalo PC hay Chrome luồng 2',
                  style='Sub.TLabel').pack(side='left')
        ttk.Label(footer,text='v'+VERSION,style='Sub.TLabel').pack(side='right')

    def _initial_split(self):
        try:
            self.panes.sashpos(0,int(self.panes.winfo_width()*.355))
        except tk.TclError:
            pass

    def _chrome_resized(self,event=None):
        if getattr(self,'chrome_host',None):
            self.after(75,self.chrome_host.resize)

    def _try_embed(self):
        host=getattr(self,'chrome_host',None)
        if not host:
            return False
        if host.attach():
            self.embedded=True
            self.browser_placeholder.place_forget()
            self.chrome_host_status.set('Trong khung ứng dụng')
            return True
        self.embedded=False
        self.chrome_host_status.set(host.reason)
        return False

    def _embed_tick(self):
        if not self.winfo_exists():
            return
        self._try_embed()
        if not self.embedded:
            self.after(1100,self._embed_tick)
        else:
            self.after(4000,self._embed_tick)

    def search_lookup(self):
        term=self.lookup_var.get().strip()
        if not term:
            self.state_label.set('Nhập tên hoặc số điện thoại cần tìm')
            return
        self.recipient_display.set('Chưa xác minh người nhận')
        self.pending_send=None
        self.dispatch('search',name=term)

    def verify_recipient(self):
        self.pending_send=None
        self.dispatch('verify_recipient',query=self.lookup_var.get().strip())

    def send_from_app(self):
        """Send is gated by an explicit review in a real modal dialog."""
        if self.send_in_progress:
            self.state_label.set('Tin trước còn đang kiểm tra; không gửi lại')
            return
        body=self.draft.get('1.0','end-1c')
        if not body.strip():
            self.state_label.set('Hãy nhập nội dung tin nhắn trước')
            return
        if len(body)>3500:
            self.state_label.set('Tin nhắn quá dài')
            return
        if self.selected_id in self.contacts:
            row=self.contacts[self.selected_id]
            if row.get('do_not_contact') or row.get('consent')=='no':
                self.state_label.set('Đã đánh dấu không liên hệ; không gửi')
                return
        self.pending_send={'text':body,'query':self.lookup_var.get().strip(),
                           'contact_id':self.selected_id if self.selected_id in self.contacts else None}
        self.dispatch('verify_recipient',query=self.pending_send['query'])

    def _review_send_modal(self,recipient,query):
        if not self.pending_send:
            return
        p=self.pending_send
        body=p['text']
        modal=tk.Toplevel(self)
        modal.title('Xác nhận gửi một tin nhắn Zalo')
        modal.transient(self)
        modal.grab_set()
        modal.geometry('530x430')
        ttk.Label(modal,text='XÁC NHẬN ĐÚNG NGƯỜI NHẬN',font=('Segoe UI',13,'bold')).pack(anchor='w',padx=16,pady=(15,8))
        ttk.Label(modal,text='Cuộc trò chuyện đã chọn: '+recipient,wraplength=485).pack(anchor='w',padx=16)
        ttk.Label(modal,text='Từ khóa đã tìm: '+(query or '(chọn trực tiếp trên Zalo)'),wraplength=485,
                  style='Sub.TLabel').pack(anchor='w',padx=16,pady=(3,10))
        ttk.Label(modal,text='Nội dung tin nhắn (chỉ đọc):').pack(anchor='w',padx=16)
        preview=tk.Text(modal,wrap='word',height=10,relief='solid',bd=1)
        preview.pack(fill='both',expand=True,padx=16,pady=(6,10))
        preview.insert('1.0',body);preview.configure(state='disabled')
        checked=tk.BooleanVar(value=False)
        ttk.Checkbutton(modal,text='Tôi xác nhận đúng người nhận, nội dung và được phép liên hệ.',
                        variable=checked).pack(anchor='w',padx=16,pady=(3,10))
        row=ttk.Frame(modal);row.pack(fill='x',padx=16,pady=(0,14))
        def confirm():
            if not checked.get():return
            from uuid import uuid4
            self.send_in_progress=True
            self.state_label.set('Đang gửi một lần và kiểm tra trạng thái...')
            modal.destroy()
            self.dispatch('send_once',recipient=recipient,query=query,text=body,
                          request_id=str(uuid4()),contact_id=p.get('contact_id'))
            self.pending_send=None
        self._btn(row,'Hủy',lambda:(modal.destroy(),setattr(self,'pending_send',None))).pack(side='right')
        self._btn(row,'Xác nhận gửi 1 lần',confirm,True).pack(side='right',padx=(0,8))
        modal.protocol('WM_DELETE_WINDOW',lambda:(modal.destroy(),setattr(self,'pending_send',None)))

    def dispatch(self,command,**kwargs):
        if command=='cancel_scan' and self.worker:self.worker.submit(command);self.scan_label.set('Đã yêu cầu dừng');return
        if command=='scan':self.scan_in_progress=True
        if not self.worker:
            self.state_label.set('Chrome worker chưa sẵn sàng');return
        if not self.worker.thread or not self.worker.thread.is_alive():
            self.worker.start()
        self.worker.submit(command,**kwargs)

    def _poll(self):
        try:
            while True:
                x=self.events.get_nowait();evt=x['event']
                if evt=='browser_started':self.state_label.set('Chrome riêng đã mở. Đăng nhập Zalo qua QR nếu được yêu cầu.')
                elif evt=='session':
                    labels={'CHAT_READY':'Đã nhận diện giao diện Zalo Web', 'QR_REQUIRED':'Chờ quét/xác nhận QR trên điện thoại',
                       'UNVERIFIED':'Chưa xác minh trạng thái đăng nhập', 'MARKETING':'Đang ở trang giới thiệu, không phải chat'}
                    self.state_label.set(labels.get(x.get('status'),x.get('status','Chưa xác minh')))
                elif evt=='browser_focused':self.state_label.set('Đã mở Chrome riêng của Zalo')
                elif evt=='friend_probe':
                    self.scan_label.set(f"Danh bạ: {x['count']} người, {x['visible_rows']} hàng đang thấy" if x.get('ready') else f"Chưa hỗ trợ màn hình này: {x.get('code','không rõ')}")
                elif evt=='scan_progress':self.scan_label.set(f"Đang quét: {x['seen']}/{x['expected']} — trang {x['page']}")
                elif evt=='scan_result':
                    self.scan_in_progress=False
                    self.scan_label.set(f"Quét xong {x['count']} liên hệ; cần xét {x['ambiguous']} tên trùng" if x.get('ok') else f"Chưa nhập danh bạ: {x.get('code','không rõ')}")
                    if x.get('ok'):self.refresh_contacts()
                elif evt=='search_ready':
                    self.state_label.set('Đã tìm kiếm. Chọn đúng người trong Zalo rồi bấm Kiểm tra người nhận.')
                elif evt=='recipient_verified':
                    display=x.get('recipient','')
                    self.recipient_display.set('Người nhận trên Zalo: '+display)
                    self.state_label.set('Đã đọc được tên trong ô soạn. Vui lòng xác nhận trước gửi.')
                    if self.pending_send:self._review_send_modal(display,x.get('query',''))
                elif evt=='recipient_unverified':
                    self.pending_send=None
                    self.recipient_display.set('Không xác minh được người nhận')
                    self.state_label.set('Không thể gửi: '+x.get('code','RECIPIENT_NOT_VERIFIED'))
                elif evt=='send_result':
                    self.send_in_progress=False
                    code=x.get('status','UNKNOWN')
                    if code=='SENT_VERIFIED':self.state_label.set('Tin đã gửi; xác minh được tin đi trên giao diện Zalo.')
                    elif code=='UNKNOWN':self.state_label.set('Chưa xác minh được kết quả. Không gửi lại để tránh trùng.')
                    else:self.state_label.set('Không gửi: '+x.get('code',code))
                elif evt=='error':
                    self.scan_in_progress=False
                    self.state_label.set(f"Lỗi: {x.get('code','không xác định')}")
                elif evt=='browser_stopped':self.state_label.set('Chrome riêng đã dừng')
                elif evt=='update_check_done':
                    self.update_check_busy=False
                    latest=newer_version_ready()
                    if latest and latest!=VERSION:
                        self.new_version_ready=latest
                        self.state_label.set(f'Đã xác minh bản {latest}. Tự chuyển phiên bản khi PC rảnh.')
                        self.after(30_000,self._auto_restart_if_safe)
                    else:
                        status=read_update_status()
                        state=status['state']
                        if state=='UP_TO_DATE':
                            self.state_label.set('Phiên bản hiện tại đã mới nhất theo nguồn cập nhật đã xác thực.')
                        elif state=='CHECK_UNAVAILABLE':
                            self.state_label.set('Chưa kiểm tra được nguồn phát hành đáng tin cậy. Giữ nguyên bản đang chạy.')
                        elif state=='NO_RECEIPT':
                            self.state_label.set('Chưa có biên nhận từ updater. Chưa thực hiện nâng cấp.')
                        else:
                            self.state_label.set('Chưa có bản cập nhật hợp lệ để kích hoạt.')

        except queue.Empty:pass
        self.after(300,self._poll)


    def check_update_now(self):
        """Only asks the installed signed launcher to check its pinned feed."""
        if self.update_check_busy or self.restarting_for_update or self.scan_in_progress or self.send_in_progress:
            self.state_label.set('Đang có tác vụ; kiểm tra cập nhật sau khi hoàn tất.')
            return
        if self.draft.edit_modified():
            self.state_label.set('Đang sửa bản nháp; lưu trước khi kiểm tra cập nhật.')
            return
        if not installed_launcher().is_file():
            self.state_label.set('Chưa tìm thấy launcher cài đặt, không chạy cập nhật tùy ý.')
            return
        self.update_check_busy=True
        self.last_update_checked_at=time.monotonic()
        self.state_label.set('Đang kiểm tra nguồn phát hành có chữ ký...')
        threading.Thread(target=check_update_background,args=(self.events,),
            daemon=True,name='ZaloSignedUpdateCheckManual').start()

    def _auto_update_tick(self):
        """Only the fixed installed launcher can fetch/verify updates; no arbitrary shell."""
        if self.restarting_for_update:return
        if self.new_version_ready:
            self._auto_restart_if_safe()
            self.after(45_000,self._auto_update_tick)
            return
        if (not self.update_check_busy and not self.scan_in_progress and not self.send_in_progress and
                time.monotonic()-self.last_update_checked_at >= 6*60*60 and
                idle_seconds() >= 180 and installed_launcher().is_file()):
            self.update_check_busy=True
            self.last_update_checked_at=time.monotonic()
            threading.Thread(target=check_update_background,
                args=(self.events,),daemon=True,name='ZaloSignedUpdateCheck').start()
        self.after(60_000,self._auto_update_tick)

    def _auto_restart_if_safe(self):
        if not self.new_version_ready or self.restarting_for_update:return
        if self.scan_in_progress or self.send_in_progress or idle_seconds() < 300:return
        if self.draft.edit_modified():return
        self.restarting_for_update=True
        self.state_label.set('Cập nhật đã xác minh. Đang chuyển sang bản mới...')
        if self.worker:self.worker.submit('shutdown')
        self.after(500,lambda:self._finish_update_restart(0))

    def _finish_update_restart(self,retries):
        if self.worker and self.worker.thread and self.worker.thread.is_alive():
            if retries<20:
                self.after(500,lambda:self._finish_update_restart(retries+1))
            else:
                self.restarting_for_update=False
                self.state_label.set('Đã chuẩn bị bản cập nhật; ứng dụng sẽ dùng sau lần mở tiếp theo.')
            return
        launcher=installed_launcher()
        try:
            subprocess.Popen([str(launcher),'--launch'],cwd=str(launcher.parent),
                stdin=subprocess.DEVNULL,stdout=subprocess.DEVNULL,stderr=subprocess.DEVNULL,
                close_fds=True)
        except OSError:
            self.restarting_for_update=False
            self.state_label.set('Đã lưu bản cập nhật. Mở lại ứng dụng để kích hoạt.')
            return
        if getattr(self,'chrome_host',None):self.chrome_host.detach()
        self.destroy()

    def refresh_contacts(self):
        try:
            rows,total=crm.load_contacts(self.search_var.get(),self.segment.get(),500)
        except Exception:
            return
        current=self.selected_id
        self.tree.delete(*self.tree.get_children())
        self.contacts={r['id']:r for r in rows}
        for x in rows:
            self.tree.insert('', 'end',iid=x['id'],values=(x['name'],x['segment']))
        self.people_label.set(f'{total} liên hệ trong CRM'+(' (hiện tối đa 500)' if total>500 else ''))
        if current in self.contacts:self.tree.selection_set(current)

    def select_contact(self,event=None):
        items=self.tree.selection()
        if not items:return
        k=items[0];row=self.contacts.get(k)
        if not row:return
        self.selected_id=k
        self.selected_name.set(row['name']+(' — cần xác minh' if row.get('needs_review') else ''))
        self.person_segment.set(row.get('segment') or SEGMENTS[0]);self.person_consent.set(row.get('consent') or 'unknown')
        self.person_blocked.set(bool(row.get('do_not_contact')))
        self.person_region.set(row.get('region') or '')
        self.notes.delete('1.0','end');self.notes.insert('1.0',row.get('notes') or '')
        self.draft.delete('1.0','end')
        try:
            saved=crm.load_saved_draft(k)
            if saved:self.draft.insert('1.0',saved['body'])
            self.draft.edit_modified(False)
        except Exception:
            self.state_label.set('Bản nháp chưa đọc được; không ảnh hưởng hồ sơ liên hệ')

    def add_contact(self):
        name=simpledialog.askstring('Liên hệ CRM','Tên người liên hệ (chỉ lưu trong app):',parent=self)
        if not name:return
        try:crm.add_manual_contact(name);self.refresh_contacts()
        except Exception as e:messagebox.showwarning('Chưa thêm',str(e),parent=self)

    def save_profile(self):
        if not self.selected_id:return
        try:
            crm.update_contact(self.selected_id,self.person_segment.get(),self.person_consent.get(),
                self.person_blocked.get(),self.notes.get('1.0','end-1c'),self.person_region.get())
            self.refresh_contacts()
            messagebox.showinfo('Đã lưu','Đã lưu vào cơ sở dữ liệu CRM riêng.',parent=self)
        except Exception as e:messagebox.showerror('Không lưu được',str(e),parent=self)

    def generate_draft(self):
        if not self.selected_id:return
        row=self.contacts.get(self.selected_id)
        try:
            with crm.connect() as conn:
                full=conn.execute('SELECT * FROM contacts WHERE id=?',(self.selected_id,)).fetchone()
            if full is None:return
            r=make_draft(full)
            if not r.get('ok'):
                messagebox.showinfo('Chưa có bản nháp',r.get('reason','Cần kiểm tra hồ sơ'),parent=self);return
            text=r.get('message') or r.get('text') or ''
            if not text:return
            current=self.draft.get('1.0','end-1c')
            if current.strip() and current != text:
                if not messagebox.askyesno('Thay bản nháp','Thay nội dung đang hiển thị bằng bản nháp gợi ý? Nội dung cũ đã lưu sẽ vẫn được giữ trong dữ liệu cho đến khi bạn bấm Lưu bản nháp.',parent=self):return
            self.draft.delete('1.0','end');self.draft.insert('1.0',text)
        except Exception as e:messagebox.showwarning('Bản nháp',str(e),parent=self)

    def save_draft(self):
        if not self.selected_id:return
        body=self.draft.get('1.0','end-1c')
        try:
            receipt=crm.store_draft(self.selected_id,body)
            self.draft.edit_modified(False)
            self.state_label.set(f"Đã lưu bản nháp cục bộ (phiên bản {receipt['revision']}). Chưa gửi Zalo.")
        except Exception as e:
            messagebox.showwarning('Chưa lưu bản nháp',str(e),parent=self)

    def copy_draft(self):
        text=self.draft.get('1.0','end-1c').strip()
        if text:
            self.clipboard_clear();self.clipboard_append(text)
            self.state_label.set('Đã sao chép bản nháp. Chưa gửi Zalo.')

    def find_on_zalo(self):
        if self.selected_id in self.contacts:
            self.lookup_var.set(self.contacts[self.selected_id]['name'])
            self.search_lookup()

    def _close(self):
        if getattr(self,'chrome_host',None):self.chrome_host.detach()
        if self.worker:self.worker.submit('shutdown')
        self.destroy()


_instance_mutex = None

def _single_instance() -> bool:
    global _instance_mutex
    if os.name!='nt': return True
    import ctypes
    dll=ctypes.windll.kernel32
    dll.CreateMutexW.argtypes=(ctypes.c_void_p,ctypes.c_bool,ctypes.c_wchar_p)
    dll.CreateMutexW.restype=ctypes.c_void_p
    _instance_mutex=dll.CreateMutexW(None,False,'Local\\ThayLinhZaloStandaloneManager')
    return bool(_instance_mutex) and dll.GetLastError()!=183

def main():
    if not _single_instance():
        return
    try:
        Manager(run_browser=os.getenv('ZALO_STANDALONE_UI_TEST')!='1').mainloop()
    except BaseException as exc:
        # This diagnostic contains no contact/chat/QR/private data.
        try:
            file=crm.DATA_ROOT/'startup-health.json'
            file.parent.mkdir(parents=True,exist_ok=True)
            file.write_text(json.dumps({'state':'ERROR','code':type(exc).__name__},ensure_ascii=False),encoding='utf-8')
        except Exception:pass
        try:messagebox.showerror('Zalo Personal Manager','Ứng dụng chưa khởi động được. Kiểm tra startup-health.json trong thư mục dữ liệu.')
        except Exception:pass

if __name__=='__main__':main()
